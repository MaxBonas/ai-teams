import unittest

from aiteam import cli


class CliProviderTests(unittest.TestCase):
    def test_parse_command_value_json_array(self) -> None:
        parsed = cli._parse_command_value('["claude","-p","{prompt}"]')
        self.assertEqual(parsed, ["claude", "-p", "{prompt}"])

    def test_parse_command_value_shell_string(self) -> None:
        parsed = cli._parse_command_value('claude -p "{prompt}"')
        self.assertEqual(parsed, ["claude", "-p", "{prompt}"])

    def test_provider_specs_include_three_seniors(self) -> None:
        specs = cli._provider_connection_specs()
        names = {item["name"] for item in specs}
        self.assertIn("openai_pro_cli", names)
        self.assertIn("gemini_pro_cli", names)
        self.assertIn("claude_pro_cli", names)


if __name__ == "__main__":
    unittest.main()

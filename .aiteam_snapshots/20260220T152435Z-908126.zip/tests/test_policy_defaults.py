import tempfile
import unittest
from pathlib import Path

from aiteam.cli import build_default_orchestrator
from aiteam.types import ChannelType


class PolicyDefaultsTests(unittest.TestCase):
    def test_default_policy_prefers_three_subscriptions_then_openai_api(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            orchestrator = build_default_orchestrator(Path(tmp))
            policy = orchestrator.router.policy
            self.assertTrue(policy.pro_first)
            self.assertEqual(policy.max_subscription_attempts, 3)
            self.assertEqual(policy.preferred_subscription_providers[:3], ["openai", "google", "anthropic"])
            self.assertEqual(policy.preferred_api_providers, ["openai"])

    def test_default_adapter_pool_uses_openai_api_models(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            orchestrator = build_default_orchestrator(Path(tmp))
            adapters = orchestrator.router.adapters

            subscription_providers = {
                adapter.provider for adapter in adapters if adapter.channel == ChannelType.SUBSCRIPTION
            }
            self.assertTrue({"openai", "anthropic", "google"}.issubset(subscription_providers))

            api_adapters = [adapter for adapter in adapters if adapter.channel == ChannelType.API]
            self.assertTrue(api_adapters)
            self.assertTrue(all(adapter.provider == "openai" for adapter in api_adapters))
            api_models = {adapter.model for adapter in api_adapters}
            self.assertIn("gpt-4.1-mini", api_models)
            self.assertIn("gpt-4o-mini", api_models)


if __name__ == "__main__":
    unittest.main()

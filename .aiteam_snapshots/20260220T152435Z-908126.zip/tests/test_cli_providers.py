import unittest
from unittest.mock import patch

from aiteam import cli


class CliProviderTests(unittest.TestCase):
    def test_parse_command_value_json_array(self) -> None:
        parsed = cli._parse_command_value('["claude","-p","{prompt}"]')
        self.assertEqual(parsed, ["claude", "-p", "{prompt}"])

    def test_parse_command_value_shell_string(self) -> None:
        parsed = cli._parse_command_value('claude -p "{prompt}"')
        self.assertEqual(parsed, ["claude", "-p", "{prompt}"])

    def test_provider_specs_include_three_seniors(self) -> None:
        specs = cli._provider_connection_specs()
        names = {item["name"] for item in specs}
        self.assertIn("openai_pro_cli", names)
        self.assertIn("gemini_pro_cli", names)
        self.assertIn("claude_pro_cli", names)

    def test_resolve_provider_command_from_env(self) -> None:
        spec = {
            "provider": "anthropic",
            "env_command": "AITEAM_TEST_COMMAND",
            "candidates": [],
        }
        with patch("aiteam.cli._probe_command", return_value=True), patch.dict(
            "os.environ",
            {"AITEAM_TEST_COMMAND": '["claude","-p","{prompt}"]'},
            clear=False,
        ):
            command = cli._resolve_provider_command(spec)
            self.assertEqual(command, ["claude", "-p", "{prompt}"])

    def test_resolve_provider_command_preserves_npx_args(self) -> None:
        spec = {
            "provider": "google",
            "candidates": [["npx", "-y", "@google/gemini-cli", "--help"]],
        }
        with patch("aiteam.cli._probe_command", return_value=True):
            command = cli._resolve_provider_command(spec)
            self.assertEqual(command, ["npx", "-y", "@google/gemini-cli", "{prompt}"])


if __name__ == "__main__":
    unittest.main()

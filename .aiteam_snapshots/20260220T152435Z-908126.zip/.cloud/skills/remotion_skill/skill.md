# remotion_skill

Buenas practicas de Remotion para MP4

## Objetivo
Usar esta skill cuando la tarea requiera este dominio.

## Capacidades
- multimodal
- rendering
- video_generation

## Guardrails
- No exponer secretos ni credenciales.
- Priorizar cambios pequenos, verificables y con evidencia.

# n8n_skill

Patrones de automatizacion para n8n

## Objetivo
Usar esta skill cuando la tarea requiera este dominio.

## Capacidades
- automation
- workflow_orchestration

## Guardrails
- No exponer secretos ni credenciales.
- Priorizar cambios pequenos, verificables y con evidencia.

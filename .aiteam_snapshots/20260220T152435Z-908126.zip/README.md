# AI Team Hybrid Orchestrator

Este proyecto inicia un sistema de AI Team con enfoque **Pro-first + API fallback**:

- Prioriza primero tus **3 canales de suscripcion** (OpenAI, Anthropic, Google) para reducir coste marginal.
- Hace fallback a **APIs GPT de costo contenido** cuando hay bloqueo, cuota, timeout o requisito tecnico.
- Orquesta perfiles (Lead, Researcher, Engineer, Reviewer, QA) sobre una task board compartida.

## Estado actual

Incluye una base funcional para:

- Definir tareas con dependencias.
- Enrutar prompts entre adapters de suscripcion y API.
- Registrar mensajeria interna de equipo (mailbox).
- Aplicar gates de calidad automaticas (review + QA) para tareas de Engineer.
- Abrir gate extra de security para tareas de riesgo.
- Gestionar locks de archivos para evitar colisiones entre agentes.
- Crear workspaces aislados por agente/tarea en `runtime/sandboxes/`.
- Controlar presupuesto API diario/mensual (FinOps).
- Ajustar consumo API con señal dinamica de presupuesto (downgrade por presion).
- Registrar eventos operativos para observabilidad (`runtime/events.jsonl`).
- Mantener memoria individual por agente (`runtime/memory/*.jsonl`).
- Ejecutar reuniones de sincronizacion y minutos compartidos por mailbox.
- Ejecutar planes locales (`cmd`, `powershell`, `browser_fetch`, `browser_open`) con guardrails.
- Bloquear operaciones sensibles sin aprobacion explicita por tarea.
- Exigir doble aprobacion en `prod` para operaciones sensibles.
- Redactar secretos comunes en contexto operativo y resultados de ejecucion.
- Ejecutar un flujo demo y persistir estado en `runtime/`.
- Generar inventario de herramientas externas con sugerencias de adapters.
- Auto-integrar herramientas (`cli|mcp|skill`) por tarea mediante `tool_requirements`.
- Biblioteca de skills con sincronizacion automatica y guia contextual por tarea.

## Estructura

- `docs/TASKS_AI_TEAM.md`: plan profundo de implementacion (19 frentes).
- `docs/ARCHITECTURE.md`: arquitectura implementada y gaps a produccion.
- `docs/INTERNAL_QUALITIES_ROADMAP.md`: cualidades objetivo y hoja de ruta interna.
- `docs/EXTERNAL_TOOLS_INVENTORY.md`: inventario de herramientas externas y prioridad.
- `docs/SECURITY_COMPLIANCE.md`: reglas de aprobacion y redaccion para operaciones sensibles.
- `docs/PRODUCTION_ROLLOUT_RUNBOOK.md`: despliegue gradual, incidentes y rollback operativo.
- `docs/MCP_CLI_SKILLS_ROADMAP.md`: roadmap v2 para MCP/CLI/Skills e integraciones profundas.
- `docs/LLM_CONNECTION_SYSTEM.md`: guia completa para conectar LLMs API y no API.
- `aiteam/`: nucleo del orquestador.
- `tests/`: pruebas base de router y taskboard.

## Uso rapido

```bash
python -m aiteam.cli init
python -m aiteam.cli plan
python -m aiteam.cli contract-first --epic-id EPIC-101 --title "Refactor auth"
python -m aiteam.cli run --rounds 12
python -m aiteam.cli demo
python -m aiteam.cli meeting --topic "Sprint Sync"
python -m aiteam.cli memory --agent eng-1 --limit 5
python -m aiteam.cli exec --shell powershell --command-text "Write-Output 'hi'"
python -m aiteam.cli adapters
python -m aiteam.cli catalog-tools
python -m aiteam.cli inventory-tools --inventory-output runtime/tool_inventory.json
python -m aiteam.cli tool-catalog
python -m aiteam.cli tool-sync --tool-request-file runtime/tool_requests.json
python -m aiteam.cli tool-sync --runtime-dir runtime_stage --tool-request-file config/tool_requests.pro.json
python -m aiteam.cli skills-library --show-content
python -m aiteam.cli skills-sync
python -m aiteam.cli mcp-status
python -m aiteam.cli mcp-doctor --doctor-timeout 20
python -m aiteam.cli provider-status --environment stage
python -m aiteam.cli provider-connect --runtime-dir runtime_stage_mcp
python -m aiteam.cli provider-doctor --runtime-dir runtime_stage_mcp
python -m aiteam.cli system-check --environment stage --strict
python -m aiteam.cli snapshot-create --snapshot-label "before-major-change"
python -m aiteam.cli snapshot-list
python -m aiteam.cli snapshot-restore --snapshot-id <id>
python -m aiteam.cli skills-coverage
python -m aiteam.cli dashboard --dashboard-output runtime/dashboard.html
python -m aiteam.cli status
python -m aiteam.cli pilot-check --environment stage
```

Opcional: usa Playwright para `browser_script` con `--browser-mode playwright`.
`init` crea `runtime/adapters.json` como template para enchufar tus runtimes externos por rol.

Setup rapido de Playwright (Python):

```bash
python -m pip install playwright
python -m playwright install chromium
```

Variables de entorno:

- Copia `.env.example` a `.env` y ajusta cuentas/proveedores.
- La CLI carga `.env` automaticamente si existe.

## Notas

- Los adapters actuales son base/simulacion para validar arquitectura.
- La integracion real con tus programas agenticos se implementa via el contrato `ModelAdapter`.
- La politica Pro-first se ajusta en `aiteam/router.py` y `aiteam/config.py`.
- El presupuesto API se evalua antes de cada intento en canal API.
- En defaults, API fallback usa `gpt-4.1-mini` (razonamiento) y `gpt-4o-mini` (multimodal).
- Stack Pro por defecto: `gpt-5.3-codex` (senior #1), `gemini-3.1-pro` (senior #2), `claude-code` (senior #3).
- El ejecutor permite workdirs dentro de `Ai_Teams` y `Antigravity Projects` (configurable con `AITEAM_SHARED_TOOLS_ROOT`).
- `mcp-doctor` verifica salud de MCPs y marca estado en `runtime/mcp_servers.json`.
- Si una adquisicion opcional falla, la tool queda auto-desactivada (`enabled=false`).
- Failover de agentes por rol con handoff de memoria para continuidad cuando hay fallos tecnicos/límites.
- `init` genera `runtime/provider_accounts.json` y `provider-status` permite revisar conectividad de cuentas Pro/API.

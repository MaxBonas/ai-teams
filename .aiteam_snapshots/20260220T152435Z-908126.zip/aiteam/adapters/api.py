from __future__ import annotations

import os
import time

from aiteam.adapters.base import ModelAdapter
from aiteam.types import AdapterResponse, ChannelType


class ApiAdapter(ModelAdapter):
    """Adapter base para providers via API."""

    def __init__(
        self,
        name: str,
        provider: str,
        model: str,
        capabilities: set[str] | None = None,
        cost_tier: int = 2,
        require_key: bool = False,
        role_targets: set[str] | None = None,
        routing_priority: int = 100,
        requires_approval: bool = False,
    ) -> None:
        super().__init__(
            name=name,
            provider=provider,
            model=model,
            channel=ChannelType.API,
            capabilities=capabilities,
            cost_tier=cost_tier,
            role_targets=role_targets,
            routing_priority=routing_priority,
            requires_approval=requires_approval,
        )
        self.require_key = require_key

    def available(self) -> bool:
        degraded_key = f"AITEAM_PROVIDER_{self.provider.upper()}_DEGRADED"
        degraded = os.getenv(degraded_key, "0").strip().lower()
        if degraded in {"1", "true", "yes", "on"}:
            return False

        enforce_keys = os.getenv("AITEAM_REQUIRE_API_KEYS", "0").strip().lower() in {
            "1",
            "true",
            "yes",
            "on",
        }
        if not self.require_key and not enforce_keys:
            return True
        key_name = f"{self.provider.upper()}_API_KEY"
        return bool(os.getenv(key_name))

    def invoke(self, prompt: str) -> AdapterResponse:
        start = time.time()
        input_tokens = max(1, len(prompt) // 4)
        content = f"[{self.provider}:{self.model}:api] Processed prompt ({len(prompt)} chars)."
        return AdapterResponse(
            success=True,
            content=content,
            latency_ms=int((time.time() - start) * 1000),
            input_tokens=input_tokens,
            output_tokens=max(1, len(content) // 4),
            error=None,
        )

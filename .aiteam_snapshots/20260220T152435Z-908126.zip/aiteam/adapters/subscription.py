from __future__ import annotations

import os
import time

from aiteam.adapters.base import ModelAdapter
from aiteam.types import AdapterResponse, ChannelType


class SubscriptionAdapter(ModelAdapter):
    """Adapter base para canales incluidos en suscripcion (Pro-first)."""

    def __init__(
        self,
        name: str,
        provider: str,
        model: str,
        capabilities: set[str] | None = None,
        cost_tier: int = 0,
        role_targets: set[str] | None = None,
        routing_priority: int = 100,
        requires_approval: bool = False,
    ) -> None:
        super().__init__(
            name=name,
            provider=provider,
            model=model,
            channel=ChannelType.SUBSCRIPTION,
            capabilities=capabilities,
            cost_tier=cost_tier,
            role_targets=role_targets,
            routing_priority=routing_priority,
            requires_approval=requires_approval,
        )

    def available(self) -> bool:
        enabled_key = f"AITEAM_SUBSCRIPTION_{self.provider.upper()}_ENABLED"
        limit_key = f"AITEAM_SUBSCRIPTION_{self.provider.upper()}_LIMIT_REACHED"
        degraded_key = f"AITEAM_PROVIDER_{self.provider.upper()}_DEGRADED"

        enabled = os.getenv(enabled_key, "1").strip().lower()
        if enabled in {"0", "false", "no", "off"}:
            return False

        limit_reached = os.getenv(limit_key, "0").strip().lower()
        if limit_reached in {"1", "true", "yes", "on"}:
            return False

        degraded = os.getenv(degraded_key, "0").strip().lower()
        if degraded in {"1", "true", "yes", "on"}:
            return False

        return True

    def invoke(self, prompt: str) -> AdapterResponse:
        start = time.time()
        input_tokens = max(1, len(prompt) // 4)
        if "FORCE_API_FALLBACK" in prompt:
            return AdapterResponse(
                success=False,
                content="",
                latency_ms=int((time.time() - start) * 1000),
                input_tokens=input_tokens,
                output_tokens=0,
                error="forced_api_fallback",
            )

        content = (
            f"[{self.provider}:{self.model}:subscription] "
            f"Processed prompt ({len(prompt)} chars)."
        )
        return AdapterResponse(
            success=True,
            content=content,
            latency_ms=int((time.time() - start) * 1000),
            input_tokens=input_tokens,
            output_tokens=max(1, len(content) // 4),
            error=None,
        )

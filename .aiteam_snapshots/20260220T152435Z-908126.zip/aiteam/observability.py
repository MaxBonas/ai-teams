from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class EventLogger:
    def __init__(self, runtime_dir: Path) -> None:
        self.log_path = runtime_dir / "events.jsonl"
        runtime_dir.mkdir(parents=True, exist_ok=True)
        if not self.log_path.exists():
            self.log_path.write_text("", encoding="utf-8")

    def emit(self, event_type: str, payload: dict[str, Any]) -> None:
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "event_type": event_type,
            "payload": payload,
        }
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=True) + "\n")

    def summary(self) -> dict[str, Any]:
        event_types = Counter()
        provider_counts = Counter()
        channel_counts = Counter()
        task_execution_total = 0
        task_execution_success = 0

        for record in self._records():
            event_types[str(record.get("event_type", "unknown"))] += 1
            if str(record.get("event_type", "")) != "task_execution":
                continue

            payload = record.get("payload", {})
            if not isinstance(payload, dict):
                continue
            task_execution_total += 1
            if bool(payload.get("success", False)):
                task_execution_success += 1
            provider_counts[str(payload.get("provider", "unknown"))] += 1
            channel_counts[str(payload.get("channel", "unknown"))] += 1

        success_rate = 0.0
        if task_execution_total > 0:
            success_rate = round((task_execution_success / task_execution_total) * 100.0, 2)

        api_share = 0.0
        if task_execution_total > 0:
            api_share = round((channel_counts.get("api", 0) / task_execution_total) * 100.0, 2)

        compliance_violations = int(event_types.get("compliance_violation", 0))
        quality_gates_opened = int(event_types.get("quality_gates_opened", 0))
        task_failed_events = int(event_types.get("task_failed", 0))

        alerts: list[str] = []
        if compliance_violations > 0:
            alerts.append(f"compliance_violations_detected:{compliance_violations}")
        if task_execution_total >= 5 and success_rate < 85.0:
            alerts.append(f"low_task_execution_success_rate:{success_rate}")
        if task_execution_total >= 5 and api_share > 40.0:
            alerts.append(f"high_api_dependency:{api_share}")
        if task_failed_events >= 3:
            alerts.append(f"recurrent_task_failures:{task_failed_events}")

        return {
            "total_events": sum(event_types.values()),
            "event_types": dict(event_types),
            "task_execution_total": task_execution_total,
            "task_execution_success": task_execution_success,
            "task_execution_success_rate": success_rate,
            "providers": dict(provider_counts),
            "channels": dict(channel_counts),
            "api_share_percent": api_share,
            "compliance_violations": compliance_violations,
            "quality_gates_opened": quality_gates_opened,
            "alerts": alerts,
            "alert_count": len(alerts),
        }

    def _records(self) -> list[dict[str, Any]]:
        raw = self.log_path.read_text(encoding="utf-8")
        items: list[dict[str, Any]] = []
        for line in raw.splitlines():
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict):
                continue
            items.append(record)
        return items

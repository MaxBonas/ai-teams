from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from aiteam.types import RoutingDecision


@dataclass
class BudgetPolicy:
    daily_api_budget_usd: float = 10.0
    monthly_api_budget_usd: float = 200.0


@dataclass
class ApiBudgetSignal:
    can_use_api: bool
    reason: str
    daily_utilization_ratio: float
    monthly_utilization_ratio: float
    max_api_cost_tier: int
    suggested_max_api_attempts: int


class BudgetManager:
    """Gestiona gasto API y aplica guardrails de presupuesto."""

    def __init__(
        self,
        runtime_dir: Path,
        policy: BudgetPolicy,
        model_cost_per_1k_tokens: dict[str, float] | None = None,
    ) -> None:
        self.runtime_dir = runtime_dir
        self.policy = policy
        self.ledger_path = runtime_dir / "cost_ledger.jsonl"
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        if not self.ledger_path.exists():
            self.ledger_path.write_text("", encoding="utf-8")
        self.model_cost_per_1k_tokens = model_cost_per_1k_tokens or {
            "gpt-4.1-mini": 0.008,
            "gpt-4o-mini": 0.01,
            "gpt-api-premium": 0.03,
            "claude-api-premium": 0.03,
            "gemini-api-pro": 0.02,
        }

    def can_use_api(self) -> tuple[bool, str]:
        snapshot = self.snapshot()
        if snapshot["daily_api_spend_usd"] >= self.policy.daily_api_budget_usd:
            return False, "daily_api_budget_exceeded"
        if snapshot["monthly_api_spend_usd"] >= self.policy.monthly_api_budget_usd:
            return False, "monthly_api_budget_exceeded"
        return True, "ok"

    def api_signal(self) -> ApiBudgetSignal:
        snapshot = self.snapshot()
        can_use, reason = self.can_use_api()

        daily_ratio = float(snapshot.get("daily_utilization_ratio", 0.0))
        monthly_ratio = float(snapshot.get("monthly_utilization_ratio", 0.0))
        pressure = max(daily_ratio, monthly_ratio)

        max_tier = 2
        max_attempts = 2
        if pressure >= 0.9:
            max_tier = 1
            max_attempts = 1
        elif pressure >= 0.75:
            max_tier = 1
            max_attempts = 1
        elif pressure >= 0.5:
            max_tier = 2
            max_attempts = 1

        if not can_use:
            max_tier = 0
            max_attempts = 0

        return ApiBudgetSignal(
            can_use_api=can_use,
            reason=reason,
            daily_utilization_ratio=round(daily_ratio, 4),
            monthly_utilization_ratio=round(monthly_ratio, 4),
            max_api_cost_tier=max_tier,
            suggested_max_api_attempts=max_attempts,
        )

    def record_routing_decision(self, decision: RoutingDecision) -> float:
        now = datetime.now(timezone.utc)
        cost = self._estimate_cost_usd(decision)
        payload = {
            "ts": now.isoformat(),
            "provider": decision.provider,
            "model": decision.model,
            "channel": decision.channel.value,
            "reason": decision.reason,
            "success": decision.success,
            "input_tokens": decision.response.input_tokens,
            "output_tokens": decision.response.output_tokens,
            "cost_usd": round(cost, 8),
        }
        with self.ledger_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=True) + "\n")
        return cost

    def snapshot(self) -> dict[str, float]:
        now = datetime.now(timezone.utc)
        day = now.date().isoformat()
        month = now.strftime("%Y-%m")
        daily = 0.0
        monthly = 0.0
        entries = 0

        for record in self._records():
            ts = record.get("ts", "")
            if not ts:
                continue
            entries += 1
            cost = float(record.get("cost_usd", 0.0))
            if ts.startswith(day):
                daily += cost
            if ts.startswith(month):
                monthly += cost

        return {
            "entries": float(entries),
            "daily_api_spend_usd": round(daily, 6),
            "monthly_api_spend_usd": round(monthly, 6),
            "daily_api_budget_usd": self.policy.daily_api_budget_usd,
            "monthly_api_budget_usd": self.policy.monthly_api_budget_usd,
            "daily_utilization_ratio": self._ratio(daily, self.policy.daily_api_budget_usd),
            "monthly_utilization_ratio": self._ratio(monthly, self.policy.monthly_api_budget_usd),
        }

    def _records(self) -> list[dict]:
        raw = self.ledger_path.read_text(encoding="utf-8")
        data: list[dict] = []
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return data

    def _estimate_cost_usd(self, decision: RoutingDecision) -> float:
        if decision.channel.value != "api":
            return 0.0

        total_tokens = max(1, decision.response.input_tokens + decision.response.output_tokens)
        per_1k = self.model_cost_per_1k_tokens.get(decision.model, 0.04)
        return (total_tokens / 1000.0) * per_1k

    @staticmethod
    def _ratio(value: float, budget: float) -> float:
        if budget <= 0:
            return 0.0
        return round(value / budget, 6)

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any


@dataclass
class CompliancePolicy:
    environment: str = "dev"
    require_sensitive_approval: bool = True
    min_approvers_by_environment: dict[str, int] = field(
        default_factory=lambda: {"dev": 1, "stage": 1, "prod": 2}
    )
    sensitive_command_patterns: list[str] = field(
        default_factory=lambda: [
            r"\b(playstore|google\s+play|publish|release|deploy|production|prod)\b",
            r"\b(terraform\s+apply|kubectl\s+apply|docker\s+push)\b",
            r"\b(whatsapp|twilio|send\s+message)\b",
        ]
    )
    redaction_patterns: list[str] = field(
        default_factory=lambda: [
            r"(?i)(api[_-]?key\s*[:=]\s*)([^\s,;]+)",
            r"(?i)(token\s*[:=]\s*)([^\s,;]+)",
            r"(?i)(secret\s*[:=]\s*)([^\s,;]+)",
            r"(?i)(password\s*[:=]\s*)([^\s,;]+)",
            r"\b(sk-[A-Za-z0-9]{12,})\b",
            r"\b(ghp_[A-Za-z0-9]{12,})\b",
        ]
    )


class ComplianceGuard:
    def __init__(self, policy: CompliancePolicy | None = None) -> None:
        self.policy = policy or CompliancePolicy()
        self._compiled_sensitive = [
            re.compile(pattern, flags=re.IGNORECASE)
            for pattern in self.policy.sensitive_command_patterns
        ]
        self._compiled_redaction = [
            re.compile(pattern)
            for pattern in self.policy.redaction_patterns
        ]

    def required_approvals(self) -> int:
        env = self.policy.environment.strip().lower()
        return max(1, int(self.policy.min_approvers_by_environment.get(env, 1)))

    def evaluate_sensitive_approval(self, task_metadata: dict[str, Any]) -> tuple[bool, str]:
        if not self.policy.require_sensitive_approval:
            return True, "approval_disabled"

        approved_flag = _to_bool(task_metadata.get("approved_sensitive_ops", False))
        approvers = self._approved_by(task_metadata)
        required = self.required_approvals()

        if len(approvers) >= required:
            return True, "approved"
        if approved_flag and required <= 1:
            return True, "approved"
        if approved_flag:
            return False, f"insufficient_approvers_required_{required}"
        return False, "sensitive_commands_require_approval"

    def approved_adapters(self, task_metadata: dict[str, Any]) -> set[str]:
        approved, _ = self.evaluate_sensitive_approval(task_metadata)
        if not approved:
            return set()
        raw = task_metadata.get("approved_adapters", [])
        if not isinstance(raw, list):
            return set()
        return {str(name).strip() for name in raw if str(name).strip()}

    def redact_text(self, value: str) -> str:
        redacted = value
        for pattern in self._compiled_redaction:
            redacted = pattern.sub(self._redact_match, redacted)
        return redacted

    def validate_execution_plan(
        self,
        plan: list[dict],
        task_metadata: dict,
    ) -> tuple[bool, str, list[str]]:
        sensitive_commands: list[str] = []
        for step in plan:
            if not isinstance(step, dict):
                continue
            step_type = str(step.get("type", "")).strip().lower()
            if step_type not in {"cmd", "powershell"}:
                continue
            command = str(step.get("command", "")).strip()
            if not command:
                continue
            if self.is_sensitive_command(command):
                sensitive_commands.append(command)

        if not sensitive_commands:
            return True, "ok", []

        if not self.policy.require_sensitive_approval:
            return True, "approval_disabled", sensitive_commands

        approved, reason = self.evaluate_sensitive_approval(task_metadata)
        if approved:
            return True, "approved", sensitive_commands

        return False, reason, sensitive_commands

    def is_sensitive_command(self, command: str) -> bool:
        normalized = command.strip().lower()
        for pattern in self._compiled_sensitive:
            if pattern.search(normalized):
                return True
        return False

    @staticmethod
    def _redact_match(match: re.Match[str]) -> str:
        if match.lastindex and match.lastindex >= 2:
            return f"{match.group(1)}<redacted>"
        return "<redacted>"

    @staticmethod
    def _approved_by(task_metadata: dict[str, Any]) -> list[str]:
        raw = task_metadata.get("approved_by", [])
        if not isinstance(raw, list):
            return []
        items = []
        for item in raw:
            text = str(item).strip()
            if text:
                items.append(text)
        return items


def _to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    normalized = str(value).strip().lower()
    return normalized in {"1", "true", "yes", "on"}

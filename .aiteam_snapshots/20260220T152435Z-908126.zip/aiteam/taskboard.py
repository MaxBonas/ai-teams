from __future__ import annotations

import json
import threading
from pathlib import Path

from aiteam.runtime import FileLockRegistry
from aiteam.types import TaskState, WorkTask


class TaskBoard:
    def __init__(self, storage_path: Path) -> None:
        self.storage_path = storage_path
        self._lock = threading.RLock()
        self._tasks: dict[str, WorkTask] = {}
        self._file_locks = FileLockRegistry(storage_path.parent / "file_locks.json")
        self._load()

    def add_task(self, task: WorkTask) -> None:
        with self._lock:
            if task.task_id in self._tasks:
                raise ValueError(f"Task already exists: {task.task_id}")
            if task.dependencies:
                task.state = TaskState.PENDING
            else:
                task.state = TaskState.READY
            self._tasks[task.task_id] = task
            self._save()

    def get_task(self, task_id: str) -> WorkTask | None:
        with self._lock:
            return self._tasks.get(task_id)

    def list_tasks(self) -> list[WorkTask]:
        with self._lock:
            return list(self._tasks.values())

    def ready_tasks(self) -> list[WorkTask]:
        with self._lock:
            self._refresh_readiness()
            return [t for t in self._tasks.values() if t.state == TaskState.READY]

    def claim_task(self, task_id: str, assignee: str) -> bool:
        with self._lock:
            self._refresh_readiness()
            task = self._tasks.get(task_id)
            if not task or task.state != TaskState.READY:
                return False
            owned_files = self._owned_files(task)
            if owned_files:
                acquired, conflicts = self._file_locks.acquire(task_id=task.task_id, files=owned_files)
                if not acquired:
                    task.state = TaskState.BLOCKED
                    task.metadata["blocked_by_files"] = conflicts
                    task.metadata["owned_files"] = owned_files
                    self._save()
                    return False
            task.state = TaskState.CLAIMED
            task.assignee = assignee
            self._save()
            return True

    def mark_completed(self, task_id: str, details: str = "") -> None:
        with self._lock:
            task = self._require(task_id)
            task.state = TaskState.COMPLETED
            self._file_locks.release_for_task(task_id)
            if details:
                task.metadata["result"] = details
            self._refresh_readiness()
            self._save()

    def mark_failed(self, task_id: str, error: str) -> None:
        with self._lock:
            task = self._require(task_id)
            task.state = TaskState.FAILED
            self._file_locks.release_for_task(task_id)
            task.metadata["error"] = error
            self._save()

    def mark_blocked(self, task_id: str, reason: str) -> None:
        with self._lock:
            task = self._require(task_id)
            task.state = TaskState.BLOCKED
            task.metadata["blocked_reason"] = reason
            self._save()

    def update_metadata(self, task_id: str, patch: dict) -> None:
        with self._lock:
            task = self._require(task_id)
            task.metadata.update(patch)
            self._save()

    def retry_task(self, task_id: str, reason: str, assignee: str | None = None) -> None:
        with self._lock:
            task = self._require(task_id)
            self._file_locks.release_for_task(task_id)
            task.state = TaskState.READY
            task.assignee = assignee
            task.metadata.pop("error", None)
            task.metadata["retry_reason"] = reason
            task.metadata["retry_count"] = int(task.metadata.get("retry_count", 0)) + 1
            self._save()

    def _refresh_readiness(self) -> None:
        for task in self._tasks.values():
            if task.state in (TaskState.COMPLETED, TaskState.CLAIMED, TaskState.FAILED):
                continue
            if task.state == TaskState.BLOCKED:
                if task.metadata.get("blocked_by_files"):
                    # Se reevalua solo al liberar locks, manteniendo trazabilidad de bloqueo.
                    task.state = TaskState.PENDING
                    task.metadata.pop("blocked_by_files", None)
                else:
                    continue
            if not task.dependencies:
                task.state = TaskState.READY
                continue

            unresolved = [
                dep
                for dep in task.dependencies
                if dep not in self._tasks or self._tasks[dep].state != TaskState.COMPLETED
            ]
            task.state = TaskState.PENDING if unresolved else TaskState.READY

    @staticmethod
    def _owned_files(task: WorkTask) -> list[str]:
        raw = task.metadata.get("owned_files", [])
        if not isinstance(raw, list):
            return []
        return [str(path) for path in raw]

    def _require(self, task_id: str) -> WorkTask:
        task = self._tasks.get(task_id)
        if not task:
            raise KeyError(f"Task not found: {task_id}")
        return task

    def _save(self) -> None:
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        payload = [self._task_to_dict(task) for task in self._tasks.values()]
        self.storage_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def _load(self) -> None:
        if not self.storage_path.exists():
            return
        raw = self.storage_path.read_text(encoding="utf-8")
        if not raw.strip():
            return
        payload = json.loads(raw)
        for item in payload:
            task = self._task_from_dict(item)
            self._tasks[task.task_id] = task

    @staticmethod
    def _task_to_dict(task: WorkTask) -> dict:
        return {
            "task_id": task.task_id,
            "title": task.title,
            "description": task.description,
            "role": task.role.value,
            "complexity": task.complexity.value,
            "criticality": task.criticality.value,
            "dependencies": task.dependencies,
            "state": task.state.value,
            "assignee": task.assignee,
            "metadata": task.metadata,
        }

    @staticmethod
    def _task_from_dict(item: dict) -> WorkTask:
        from aiteam.types import Complexity, Criticality, Role

        return WorkTask(
            task_id=item["task_id"],
            title=item["title"],
            description=item["description"],
            role=Role(item["role"]),
            complexity=Complexity(item["complexity"]),
            criticality=Criticality(item["criticality"]),
            dependencies=item.get("dependencies", []),
            state=TaskState(item.get("state", TaskState.PENDING.value)),
            assignee=item.get("assignee"),
            metadata=item.get("metadata", {}),
        )

from __future__ import annotations

import argparse
import os
import webbrowser
import shutil
import subprocess
import shlex
from pathlib import Path
import json
from datetime import datetime, timezone

from aiteam.adapters import (
    ApiAdapter,
    SubscriptionAdapter,
    build_external_adapter_template,
    load_external_adapters,
)
from aiteam.autotools import AutoToolIntegrator
from aiteam.communication import MeetingParticipant
from aiteam.config import build_default_router_policy
from aiteam.dashboard import build_dashboard_payload, render_dashboard_html
from aiteam.finops import BudgetManager, BudgetPolicy
from aiteam.observability import EventLogger
from aiteam.orchestrator import AITeamOrchestrator
from aiteam.pilot import PilotThresholds, compute_pilot_metrics, evaluate_pilot
from aiteam.router import HybridRouter
from aiteam.snapshots import SnapshotManager
from aiteam.tool_inventory import write_inventory
from aiteam.types import Complexity, Criticality, Role, WorkTask


def _load_dotenv_if_present(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        raw = line.strip()
        if not raw or raw.startswith("#"):
            continue
        if "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        env_key = key.strip()
        if not env_key or env_key in os.environ:
            continue
        clean_value = value.strip().strip('"').strip("'")
        os.environ[env_key] = clean_value


def build_default_orchestrator(
    runtime_dir: Path,
    browser_mode: str = "basic",
    environment: str = "dev",
) -> AITeamOrchestrator:
    policy = build_default_router_policy()
    budget = BudgetManager(
        runtime_dir=runtime_dir,
        policy=BudgetPolicy(
            daily_api_budget_usd=policy.daily_api_budget_usd,
            monthly_api_budget_usd=policy.monthly_api_budget_usd,
        ),
    )
    event_logger = EventLogger(runtime_dir)

    adapters = [
        SubscriptionAdapter(
            name="openai_pro",
            provider="openai",
            model="gpt-5.3-codex",
            capabilities={"reasoning", "coding", "review"},
        ),
        SubscriptionAdapter(
            name="gemini_pro",
            provider="google",
            model="gemini-3.1-pro",
            capabilities={"analysis", "summarization", "reasoning", "coding"},
        ),
        SubscriptionAdapter(
            name="claude_pro",
            provider="anthropic",
            model="claude-code",
            capabilities={"reasoning", "coding", "analysis"},
        ),
        ApiAdapter(
            name="openai_api_reasoning",
            provider="openai",
            model="gpt-4.1-mini",
            capabilities={"reasoning", "coding", "analysis", "review"},
            cost_tier=1,
        ),
        ApiAdapter(
            name="openai_api_multimodal",
            provider="openai",
            model="gpt-4o-mini",
            capabilities={"reasoning", "analysis", "multimodal", "tool_calling"},
            cost_tier=2,
        ),
    ]

    external_config_path = runtime_dir / "adapters.json"
    external_adapters = load_external_adapters(external_config_path)
    if external_adapters:
        adapters = external_adapters + adapters
        _prepend_provider_priority(policy.preferred_subscription_providers, external_adapters, "subscription")
        _prepend_provider_priority(policy.preferred_api_providers, external_adapters, "api")

    shared_tools_root = Path(
        os.getenv("AITEAM_SHARED_TOOLS_ROOT", str(Path.cwd().parent))
    ).resolve()
    additional_roots = [shared_tools_root] if shared_tools_root.exists() else []

    router = HybridRouter(
        adapters=adapters,
        policy=policy,
        budget_manager=budget,
        event_logger=event_logger,
    )
    return AITeamOrchestrator(
        router=router,
        runtime_dir=runtime_dir,
        project_root=Path.cwd(),
        additional_workspace_roots=additional_roots,
        browser_mode=browser_mode,
        environment=environment,
    )


def _prepend_provider_priority(priority: list[str], adapters: list, channel: str) -> None:
    providers = []
    for adapter in adapters:
        if adapter.channel.value != channel:
            continue
        if adapter.provider not in providers:
            providers.append(adapter.provider)
    for provider in reversed(providers):
        if provider in priority:
            priority.remove(provider)
        priority.insert(0, provider)


def _default_tool_requests_template() -> dict:
    return {
        "tool_requirements": [
            {
                "name": "context7_mcp",
                "required": False,
                "enabled": False,
                "acquire": True,
                "category": "mcp",
                "source_type": "npm",
                "source": "@upstash/context7-mcp",
                "capabilities": ["documentation", "ground_truth", "research"],
                "role_targets": ["researcher", "engineer"],
            },
            {
                "name": "github_mcp",
                "required": False,
                "enabled": False,
                "acquire": True,
                "category": "mcp",
                "source_type": "npm",
                "source": "@modelcontextprotocol/server-github",
                "capabilities": ["github", "pr_management", "issue_triage"],
                "role_targets": ["team_lead", "engineer", "reviewer"],
                "requires_approval": True,
            },
            {
                "name": "remotion_skill",
                "required": False,
                "category": "skill",
                "source_type": "builtin",
                "capabilities": ["video_generation", "multimodal", "rendering"],
            },
        ]
    }


def _default_provider_accounts_template() -> dict:
    return {
        "subscription_accounts": [
            {
                "provider": "openai",
                "model": "gpt-5.3-codex",
                "enabled_env": "AITEAM_SUBSCRIPTION_OPENAI_ENABLED",
                "notes": "Primary senior coder account",
            },
            {
                "provider": "google",
                "model": "gemini-3.1-pro",
                "enabled_env": "AITEAM_SUBSCRIPTION_GOOGLE_ENABLED",
                "notes": "Second senior coder account",
            },
            {
                "provider": "anthropic",
                "model": "claude-code",
                "enabled_env": "AITEAM_SUBSCRIPTION_ANTHROPIC_ENABLED",
                "notes": "Third senior coder account",
            },
        ],
        "api_accounts": [
            {
                "provider": "openai",
                "models": ["gpt-4.1-mini", "gpt-4o-mini"],
                "api_key_env": "OPENAI_API_KEY",
                "notes": "Fallback API budget-aware",
            }
        ],
    }


def _provider_connection_specs() -> list[dict]:
    return [
        {
            "name": "openai_pro_cli",
            "provider": "openai",
            "model": "gpt-5.3-codex",
            "required": True,
            "env_command": "AITEAM_OPENAI_PRO_COMMAND",
            "candidates": [
                ["codex", "--version"],
                ["npx", "-y", "@openai/codex", "--version"],
                ["opencode", "--help"],
            ],
            "command_template": [
                "npx",
                "-y",
                "@openai/codex",
                "exec",
                "--skip-git-repo-check",
                "{prompt}",
            ],
            "capabilities": ["coding", "reasoning", "review", "analysis"],
            "role_targets": ["team_lead", "engineer", "reviewer"],
            "routing_priority": 10,
            "source": "openai_pro_cli",
        },
        {
            "name": "gemini_pro_cli",
            "provider": "google",
            "model": "gemini-3.1-pro",
            "required": True,
            "env_command": "AITEAM_GEMINI_PRO_COMMAND",
            "candidates": [
                ["gemini", "--help"],
                ["gemini-cli", "--help"],
                ["npx", "-y", "@google/gemini-cli", "--help"],
            ],
            "command_suffix": ["{prompt}"],
            "capabilities": ["coding", "reasoning", "analysis", "summarization"],
            "role_targets": ["team_lead", "engineer", "researcher"],
            "routing_priority": 20,
            "source": "gemini_pro_cli",
        },
        {
            "name": "claude_pro_cli",
            "provider": "anthropic",
            "model": "claude-code",
            "required": True,
            "env_command": "AITEAM_CLAUDE_PRO_COMMAND",
            "candidates": [["claude", "--version"]],
            "command_suffix": ["-p", "{prompt}"],
            "capabilities": ["coding", "reasoning", "analysis", "review"],
            "role_targets": ["team_lead", "engineer", "reviewer", "researcher"],
            "routing_priority": 30,
            "source": "claude_pro_cli",
        },
    ]


def _resolve_provider_command(spec: dict) -> list[str] | None:
    env_key = str(spec.get("env_command", "")).strip()
    if env_key:
        raw = os.getenv(env_key, "").strip()
        parsed = _parse_command_value(raw)
        if parsed and _probe_command(parsed):
            return parsed

    candidates = spec.get("candidates", [])
    if not isinstance(candidates, list):
        return None
    for candidate in candidates:
        if not isinstance(candidate, list):
            continue
        command = [str(item) for item in candidate if str(item).strip()]
        if not command:
            continue
        if _probe_command(command):
            template = spec.get("command_template")
            if isinstance(template, list) and all(isinstance(item, str) for item in template):
                return [str(item) for item in template]

            invocation = [item for item in command if item != "--help"]
            if command[0].lower().endswith("claude") or "claude" in command[0].lower():
                return [command[0], "-p", "{prompt}"]

            if invocation and invocation[-1] != "{prompt}":
                invocation.append("{prompt}")
            return invocation
    return None


def _provider_runtime_health(spec: dict, command: list[str] | None) -> tuple[bool, str]:
    if not command:
        return False, "command_missing"
    provider = str(spec.get("provider", "")).strip().lower()
    if provider == "openai":
        return _openai_pro_health()
    if provider == "google":
        return _gemini_health(command)
    if provider == "anthropic":
        return _claude_auth_health()
    return True, "command_ok"


def _probe_command(command: list[str]) -> bool:
    if not command:
        return False
    executable = command[0]
    resolved = _resolve_executable(executable)
    if resolved is None:
        return False
    args = [resolved] + command[1:]
    try:
        proc = subprocess.run(
            args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return proc.returncode == 0


def _claude_auth_health() -> tuple[bool, str]:
    claude = shutil.which("claude")
    if not claude:
        return False, "claude_not_found"
    try:
        proc = subprocess.run(
            [claude, "auth", "status"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"claude_auth_error:{exc}"
    if proc.returncode != 0:
        return False, "claude_auth_status_failed"
    try:
        payload = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError:
        return True, "claude_auth_unknown"
    if not isinstance(payload, dict):
        return True, "claude_auth_unknown"
    logged = bool(payload.get("loggedIn", False))
    subscription = str(payload.get("subscriptionType", "unknown"))
    if not logged:
        return False, "claude_not_logged_in"
    return True, f"claude_logged_in:{subscription}"


def _openai_pro_health() -> tuple[bool, str]:
    npx = _resolve_executable("npx")
    if not npx:
        return False, "npx_not_found"
    command = [npx, "-y", "@openai/codex", "login", "status"]
    try:
        proc = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"openai_status_error:{exc}"
    if proc.returncode != 0:
        stderr = (proc.stderr or "").strip().lower()
        if "not logged in" in stderr:
            return False, "openai_not_logged_in"
        return False, "openai_status_failed"
    out = " ".join([(proc.stdout or "").strip(), (proc.stderr or "").strip()]).lower()
    if "logged in" in out:
        if "chatgpt" in out:
            return True, "openai_logged_in:chatgpt"
        return True, "openai_logged_in"
    return False, "openai_not_logged_in"


def _gemini_health(command: list[str]) -> tuple[bool, str]:
    if not command:
        return False, "gemini_command_missing"
    probe = [item.replace("{prompt}", "healthcheck") for item in command]
    resolved = _resolve_executable(probe[0])
    if resolved is None:
        return False, "gemini_command_not_found"
    probe[0] = resolved
    try:
        proc = subprocess.run(
            probe,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"gemini_probe_error:{exc}"
    if proc.returncode == 0:
        return True, "gemini_ok"
    stderr = (proc.stderr or "").strip().lower()
    stdout = (proc.stdout or "").strip().lower()
    blob = f"{stderr} {stdout}"
    if "please set an auth method" in blob:
        return False, "gemini_auth_missing"
    return False, "gemini_probe_failed"


def _resolve_executable(executable: str) -> str | None:
    name = executable.strip()
    if not name:
        return None
    resolved = shutil.which(name)
    if resolved is not None:
        return resolved
    if os.name == "nt" and not name.lower().endswith((".cmd", ".exe", ".bat")):
        for suffix in (".cmd", ".exe", ".bat"):
            resolved = shutil.which(name + suffix)
            if resolved is not None:
                return resolved
    return None


def _parse_command_value(raw: str) -> list[str] | None:
    if not raw:
        return None
    text = raw.strip()
    if text.startswith("["):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            return None
        if isinstance(parsed, list) and all(isinstance(item, str) for item in parsed):
            return [item for item in parsed if item.strip()]
        return None
    try:
        parts = shlex.split(text)
    except ValueError:
        return None
    return [part for part in parts if part.strip()]


def _load_json_file(path: Path, default: dict) -> dict:
    if not path.exists():
        return dict(default)
    raw = path.read_text(encoding="utf-8")
    if not raw.strip():
        return dict(default)
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return dict(default)
    if not isinstance(payload, dict):
        return dict(default)
    return payload


def _upsert_adapter(items: list, entry: dict) -> list:
    name = str(entry.get("name", "")).strip().lower()
    if not name:
        return items
    updated = False
    output = []
    for item in items:
        if not isinstance(item, dict):
            output.append(item)
            continue
        if str(item.get("name", "")).strip().lower() == name:
            output.append(entry)
            updated = True
        else:
            output.append(item)
    if not updated:
        output.append(entry)
    return output


def cmd_init(runtime_dir: Path) -> None:
    runtime_dir.mkdir(parents=True, exist_ok=True)
    (runtime_dir / "tasks.json").write_text("[]\n", encoding="utf-8")
    (runtime_dir / "mailbox.jsonl").write_text("", encoding="utf-8")
    (runtime_dir / "events.jsonl").write_text("", encoding="utf-8")
    (runtime_dir / "cost_ledger.jsonl").write_text("", encoding="utf-8")
    (runtime_dir / "memory").mkdir(parents=True, exist_ok=True)
    if not (runtime_dir / "mcp_servers.json").exists():
        (runtime_dir / "mcp_servers.json").write_text(
            json.dumps({"servers": []}, indent=2, ensure_ascii=True),
            encoding="utf-8",
        )
    if not (runtime_dir / "tool_registry.json").exists():
        (runtime_dir / "tool_registry.json").write_text(
            json.dumps({"entries": []}, indent=2, ensure_ascii=True),
            encoding="utf-8",
        )
    if not (runtime_dir / "adapters.json").exists():
        build_external_adapter_template(runtime_dir / "adapters.json")
    if not (runtime_dir / "tool_requests.json").exists():
        (runtime_dir / "tool_requests.json").write_text(
            json.dumps(_default_tool_requests_template(), indent=2, ensure_ascii=True),
            encoding="utf-8",
        )
    if not (runtime_dir / "provider_accounts.json").exists():
        (runtime_dir / "provider_accounts.json").write_text(
            json.dumps(_default_provider_accounts_template(), indent=2, ensure_ascii=True),
            encoding="utf-8",
        )
    print(f"Runtime initialized at: {runtime_dir}")


def cmd_plan() -> None:
    plan_path = Path("docs") / "TASKS_AI_TEAM.md"
    print(plan_path.read_text(encoding="utf-8"))


def cmd_demo(runtime_dir: Path, browser_mode: str, environment: str) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir,
        browser_mode=browser_mode,
        environment=environment,
    )

    task1 = WorkTask(
        task_id="T-001",
        title="Descomponer iniciativa AI Team",
        description="Crear plan de ejecucion para integrar tus programas agenticos.",
        role=Role.TEAM_LEAD,
        complexity=Complexity.MEDIUM,
        criticality=Criticality.MEDIUM,
    )
    task2 = WorkTask(
        task_id="T-002",
        title="Implementar policy Pro-first",
        description=(
            "Definir reglas de prioridad de suscripcion y fallback API. "
            "FORCE_API_FALLBACK"
        ),
        role=Role.ENGINEER,
        complexity=Complexity.HIGH,
        criticality=Criticality.HIGH,
        dependencies=["T-001"],
        metadata={
            "required_capabilities": ["coding"],
            "owned_files": ["aiteam/router.py", "aiteam/config.py"],
        },
    )
    task3 = WorkTask(
        task_id="T-003",
        title="Analizar estrategia de costo",
        description="Validar presupuesto diario y disparadores de fallback.",
        role=Role.RESEARCHER,
        complexity=Complexity.MEDIUM,
        criticality=Criticality.MEDIUM,
        dependencies=["T-001"],
        metadata={"required_capabilities": ["analysis"]},
    )
    task4 = WorkTask(
        task_id="T-004",
        title="Validar entorno local y browser",
        description="Ejecutar comandos de entorno y navegacion basica.",
        role=Role.ENGINEER,
        complexity=Complexity.MEDIUM,
        criticality=Criticality.MEDIUM,
        dependencies=["T-001"],
        metadata={
            "required_capabilities": ["coding"],
            "execution_plan": [
                {"type": "cmd", "command": "python --version", "timeout": 30},
                {
                    "type": "powershell",
                    "command": "Write-Output 'PowerShell OK from AI Team'",
                    "timeout": 30,
                },
                {"type": "browser_fetch", "url": "https://example.com", "timeout": 20},
                {
                    "type": "browser_script",
                    "url": "https://example.com",
                    "timeout": 30,
                    "actions": [{"type": "wait_for_selector", "selector": "body"}],
                },
            ],
        },
    )

    for task in [task1, task2, task3, task4]:
        existing = orchestrator.taskboard.get_task(task.task_id)
        if not existing:
            orchestrator.submit_task(task)

    orchestrator.run_until_idle(max_rounds=8)
    print("Demo run completed.")


def cmd_status(runtime_dir: Path, browser_mode: str, environment: str) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir,
        browser_mode=browser_mode,
        environment=environment,
    )
    print("Tasks:")
    for task in orchestrator.taskboard.list_tasks():
        print(
            f"- {task.task_id} [{task.state.value}] role={task.role.value} "
            f"assignee={task.assignee} title={task.title}"
        )
    print("\nMailbox:")
    for msg in orchestrator.mailbox.list_messages():
        print(f"- {msg.timestamp} {msg.sender} -> {msg.recipient}: {msg.subject}")
    print("\nObservability:")
    summary = orchestrator.event_logger.summary()
    pilot_metrics = compute_pilot_metrics(orchestrator.taskboard.list_tasks(), summary)
    print(f"- total_events={summary['total_events']} by_type={summary['event_types']}")
    print(f"- compliance_environment={environment}")
    print(
        "- task_execution="
        f"{summary['task_execution_success']}/{summary['task_execution_total']} "
        f"({summary['task_execution_success_rate']}%)"
    )
    print(
        f"- channels={summary['channels']} providers={summary['providers']} "
        f"quality_gates_opened={summary['quality_gates_opened']} "
        f"compliance_violations={summary['compliance_violations']}"
    )
    print(f"- api_share_percent={summary['api_share_percent']} alerts={summary['alerts']}")
    print(
        "- pilot_metrics "
        f"task_success_rate={pilot_metrics['task_success_rate']}% "
        f"gate_pass_rate={pilot_metrics['gate_pass_rate']}% "
        f"pro_share={pilot_metrics['pro_share_percent']}% "
        f"api_fallback={pilot_metrics['api_fallback_rate_percent']}%"
    )
    print(
        "- execution_roots="
        f"{[str(path) for path in orchestrator.execution.executor.allowed_roots]}"
    )

    tool_integrator = AutoToolIntegrator(runtime_dir=runtime_dir, project_root=Path.cwd())
    coverage = tool_integrator.skill_coverage(runtime_dir=runtime_dir)
    print(
        "- skills_coverage="
        f"{coverage['coverage_percent']}% "
        f"({coverage['skill_guidance_events']}/{coverage['total_task_execution']})"
    )

    budget = orchestrator.router.budget_manager
    if budget is not None:
        snapshot = budget.snapshot()
        signal = budget.api_signal()
        print(
            "\nFinOps:"
            f" daily=${snapshot['daily_api_spend_usd']}/${snapshot['daily_api_budget_usd']}"
            f" monthly=${snapshot['monthly_api_spend_usd']}/${snapshot['monthly_api_budget_usd']}"
        )
        print(
            "- budget_signal="
            f"can_use_api={signal.can_use_api} reason={signal.reason} "
            f"max_api_tier={signal.max_api_cost_tier} "
            f"suggested_api_attempts={signal.suggested_max_api_attempts}"
        )

    print("\nMemories:")
    for agent in orchestrator.memory.list_agents():
        print(f"- {agent}: {orchestrator.memory.count(agent)} entries")


def cmd_run(runtime_dir: Path, rounds: int, browser_mode: str, environment: str) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir,
        browser_mode=browser_mode,
        environment=environment,
    )
    orchestrator.run_until_idle(max_rounds=rounds)
    print(f"Run finished. max_rounds={rounds}")


def cmd_meeting(runtime_dir: Path, topic: str, browser_mode: str, environment: str) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir,
        browser_mode=browser_mode,
        environment=environment,
    )
    orchestrator.communicator.run_sync_meeting(
        topic=topic,
        participants=[
            MeetingParticipant(agent_id="lead-1", role=Role.TEAM_LEAD.value),
            MeetingParticipant(agent_id="research-1", role=Role.RESEARCHER.value),
            MeetingParticipant(agent_id="eng-1", role=Role.ENGINEER.value),
            MeetingParticipant(agent_id="review-1", role=Role.REVIEWER.value),
            MeetingParticipant(agent_id="qa-1", role=Role.QA.value),
        ],
    )
    print(f"Meeting completed: {topic}")


def cmd_memory(runtime_dir: Path, agent: str, limit: int) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir,
        browser_mode="basic",
        environment="dev",
    )
    entries = orchestrator.memory.recent(agent, limit=limit)
    if not entries:
        print(f"No memory entries for agent={agent}")
        return
    for entry in entries:
        print(f"- {entry.ts} [{entry.kind}] task={entry.task_id} {entry.content[:200]}")


def cmd_exec(runtime_dir: Path, shell: str, command: str, browser_mode: str, environment: str) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir,
        browser_mode=browser_mode,
        environment=environment,
    )
    if shell == "cmd":
        result = orchestrator.execution.executor.run_cmd(command=command)
    else:
        result = orchestrator.execution.executor.run_powershell(command=command)
    print(f"success={result.success} exit={result.exit_code} reason={result.reason}")
    if result.stdout.strip():
        print("STDOUT:")
        print(result.stdout.strip())
    if result.stderr.strip():
        print("STDERR:")
        print(result.stderr.strip())


def cmd_adapters(runtime_dir: Path, create_template: bool) -> None:
    path = runtime_dir / "adapters.json"
    if create_template:
        build_external_adapter_template(path)
        print(f"Adapter template written: {path}")
        return

    adapters = load_external_adapters(path)
    if not adapters:
        print(f"No external adapters loaded from: {path}")
        return
    print(f"Loaded {len(adapters)} external adapters:")
    for adapter in adapters:
        print(
            f"- {adapter.name} provider={adapter.provider} model={adapter.model} "
            f"channel={adapter.channel.value} roles={sorted(adapter.role_targets)} "
            f"priority={adapter.routing_priority} requires_approval={adapter.requires_approval}"
        )


def cmd_pilot_check(
    runtime_dir: Path,
    browser_mode: str,
    environment: str,
    min_task_success_rate: float,
    min_gate_pass_rate: float,
    min_pro_share: float,
    max_compliance_violations: int,
) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir,
        browser_mode=browser_mode,
        environment=environment,
    )
    summary = orchestrator.event_logger.summary()
    metrics = compute_pilot_metrics(orchestrator.taskboard.list_tasks(), summary)
    result = evaluate_pilot(
        metrics,
        PilotThresholds(
            min_task_success_rate=min_task_success_rate,
            min_gate_pass_rate=min_gate_pass_rate,
            min_pro_share_percent=min_pro_share,
            max_compliance_violations=max_compliance_violations,
        ),
    )
    print("Pilot check:")
    print(
        f"- task_success_rate={metrics['task_success_rate']}% "
        f"gate_pass_rate={metrics['gate_pass_rate']}% "
        f"pro_share={metrics['pro_share_percent']}% "
        f"api_fallback={metrics['api_fallback_rate_percent']}% "
        f"compliance_violations={metrics['compliance_violations']}"
    )
    for message in result.messages:
        print(f"- {message}")
    if not result.ok:
        raise SystemExit(1)


def cmd_catalog_tools(catalog_root: Path, limit: int) -> None:
    root = catalog_root.resolve()
    if not root.exists() or not root.is_dir():
        print(f"Catalog root not found: {root}")
        return

    projects = [path for path in root.iterdir() if path.is_dir()]
    projects.sort(key=lambda item: item.name.lower())

    print(f"Catalog root: {root}")
    print(f"Projects detected: {len(projects)}")
    for project in projects[: max(1, limit)]:
        markers: list[str] = []
        if (project / "package.json").exists():
            markers.append("node")
        if (project / "requirements.txt").exists() or (project / "pyproject.toml").exists():
            markers.append("python")
        if (project / "README.md").exists() or (project / "README.txt").exists():
            markers.append("readme")
        if list(project.glob("*.exe")):
            markers.append("exe")
        marker_text = ",".join(markers) if markers else "unknown"
        print(f"- {project.name} [{marker_text}]")


def cmd_inventory_tools(catalog_root: Path, output_path: Path, limit: int) -> None:
    payload = write_inventory(root=catalog_root, output_path=output_path, limit=limit)
    print(f"Tool inventory written: {output_path}")
    print(f"- root={payload['root']}")
    print(f"- total_tools={payload['total']}")
    for item in payload["tools"][:10]:
        print(
            f"- {item['project_name']} -> adapter={item['adapter_name']} "
            f"enabled={item['enabled']} requires_approval={item['requires_approval']}"
        )


def cmd_tool_catalog(catalog_path: Path, limit: int) -> None:
    if not catalog_path.exists():
        print(f"Tool catalog not found: {catalog_path}")
        return
    try:
        payload = json.loads(catalog_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"Tool catalog invalid JSON: {exc}")
        return

    items = payload.get("tools", [])
    if not isinstance(items, list):
        print("Tool catalog has no tools list")
        return
    print(f"Tool catalog: {catalog_path}")
    print(f"Tools: {len(items)}")
    for item in items[: max(1, limit)]:
        if not isinstance(item, dict):
            continue
        print(
            "- "
            f"{item.get('name')} category={item.get('category')} source={item.get('source_type')} "
            f"requires_approval={item.get('requires_approval', False)}"
        )


def cmd_tool_sync(
    runtime_dir: Path,
    environment: str,
    request_path: Path,
    catalog_path: Path,
    strict: bool,
    allow_internet: bool,
) -> None:
    if not request_path.exists():
        print(f"Tool request file not found: {request_path}")
        return
    try:
        payload = json.loads(request_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"Tool request JSON invalid: {exc}")
        return

    requirements = payload.get("tool_requirements", [])
    if not isinstance(requirements, list) or not requirements:
        print("No tool_requirements found")
        return

    metadata = {
        "tool_requirements": requirements,
        "auto_integrate_tools": True,
    }
    internet_allowed = allow_internet or environment != "prod"
    integrator = AutoToolIntegrator(
        runtime_dir=runtime_dir,
        project_root=Path.cwd(),
        catalog_path=catalog_path,
    )
    report = integrator.integrate_from_metadata(
        task_id="manual_tool_sync",
        metadata=metadata,
        internet_allowed=internet_allowed,
    )
    print(
        "Tool sync: "
        f"success={report.success} adapters={len(report.integrated_adapters)} "
        f"mcp={len(report.integrated_mcp_servers)} skills={len(report.integrated_skills)}"
    )
    if report.messages:
        for item in report.messages[:20]:
            print(f"- {item}")
    if report.errors:
        for item in report.errors[:20]:
            print(f"- ERROR {item}")
    if strict and not report.success:
        raise SystemExit(1)


def cmd_skills_library(runtime_dir: Path, show_content: bool) -> None:
    integrator = AutoToolIntegrator(runtime_dir=runtime_dir, project_root=Path.cwd())
    entries = integrator.skill_library_entries()
    if not entries:
        print("No skills found in library")
        return
    print(f"Skills library entries: {len(entries)}")
    for entry in entries:
        name = str(entry.get("name", "")).strip().lower()
        roles = entry.get("roles", [])
        capabilities = entry.get("capabilities", [])
        print(f"- {name} roles={roles} capabilities={capabilities}")
        if show_content:
            print(f"  purpose={entry.get('purpose', entry.get('description', ''))}")


def cmd_skills_sync(runtime_dir: Path, force: bool) -> None:
    integrator = AutoToolIntegrator(runtime_dir=runtime_dir, project_root=Path.cwd())
    created = integrator.sync_skill_library(force=force)
    print(f"Skills synced: {len(created)}")
    for item in created:
        print(f"- {item}")


def cmd_mcp_status(runtime_dir: Path) -> None:
    path = runtime_dir / "mcp_servers.json"
    if not path.exists():
        print(f"MCP registry not found: {path}")
        return
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"Invalid MCP registry JSON: {exc}")
        return
    servers = payload.get("servers", [])
    if not isinstance(servers, list) or not servers:
        print("No MCP servers registered")
        return
    enabled = 0
    print(f"MCP servers: {len(servers)}")
    for server in servers:
        if not isinstance(server, dict):
            continue
        is_enabled = bool(server.get("enabled", False))
        if is_enabled:
            enabled += 1
        health = server.get("health_status", "unknown")
        reason = server.get("health_reason", "")
        print(
            f"- {server.get('name')} enabled={is_enabled} transport={server.get('transport')} "
            f"approval={server.get('requires_approval', True)} health={health} reason={reason}"
        )
    print(f"Enabled MCP servers: {enabled}")


def cmd_mcp_doctor(
    runtime_dir: Path,
    timeout: int,
    enable_healthy: bool,
    enable_sensitive: bool,
) -> None:
    integrator = AutoToolIntegrator(runtime_dir=runtime_dir, project_root=Path.cwd())
    report = integrator.mcp_doctor(
        timeout=timeout,
        enable_healthy=enable_healthy,
        enable_sensitive=enable_sensitive,
    )
    print(
        f"MCP doctor checked={report['total']} healthy={report['healthy']} "
        f"enabled={report['enabled']} auto_enabled={report['auto_enabled']} "
        f"skipped_sensitive={report['skipped_sensitive']}"
    )
    for item in report["reports"]:
        print(
            f"- {item['name']} status={item['status']} enabled={item['enabled']} "
            f"reason={item['reason']}"
        )


def cmd_provider_status(runtime_dir: Path, environment: str) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir=runtime_dir,
        browser_mode="basic",
        environment=environment,
    )
    print("Provider status:")
    for adapter in orchestrator.router.adapters:
        if adapter.channel.value not in {"subscription", "api"}:
            continue
        print(
            f"- {adapter.name} provider={adapter.provider} model={adapter.model} "
            f"channel={adapter.channel.value} available={adapter.available()}"
        )

    key_checks = [
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "GOOGLE_API_KEY",
    ]
    print("API keys:")
    for key in key_checks:
        print(f"- {key}={'set' if bool(os.getenv(key)) else 'missing'}")


def cmd_provider_doctor(runtime_dir: Path, strict: bool) -> None:
    specs = _provider_connection_specs()
    report = {
        "providers": [],
        "api_keys": {},
        "healthy": True,
    }

    print("Provider doctor:")
    for spec in specs:
        command = _resolve_provider_command(spec)
        healthy, details = _provider_runtime_health(spec, command)

        if not healthy and spec.get("required", False):
            report["healthy"] = False

        row = {
            "provider": spec["provider"],
            "name": spec["name"],
            "healthy": healthy,
            "details": details,
            "command": command or [],
        }
        report["providers"].append(row)
        print(
            f"- {spec['name']} provider={spec['provider']} healthy={healthy} details={details}"
        )

    for key in ["OPENAI_API_KEY", "GOOGLE_API_KEY", "ANTHROPIC_API_KEY"]:
        state = "set" if bool(os.getenv(key)) else "missing"
        report["api_keys"][key] = state
        print(f"- {key}={state}")

    path = runtime_dir / "provider_doctor.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=True), encoding="utf-8")
    print(f"- report={path}")

    if strict and not report["healthy"]:
        raise SystemExit(1)


def cmd_provider_connect(runtime_dir: Path, strict: bool) -> None:
    runtime_dir.mkdir(parents=True, exist_ok=True)
    adapters_path = runtime_dir / "adapters.json"
    if not adapters_path.exists():
        build_external_adapter_template(adapters_path)

    payload = _load_json_file(adapters_path, default={"external_adapters": []})
    adapters = payload.get("external_adapters", [])
    if not isinstance(adapters, list):
        adapters = []

    specs = _provider_connection_specs()
    missing: list[str] = []
    for spec in specs:
        name = spec["name"]
        command = _resolve_provider_command(spec)
        enabled, details = _provider_runtime_health(spec, command)

        if not enabled and spec.get("required", False):
            missing.append(name)

        entry = {
            "type": "external_program",
            "name": name,
            "provider": spec["provider"],
            "model": spec["model"],
            "channel": "subscription",
            "command": command or ["python", "-c", "print('provider cli not configured')"],
            "capabilities": spec["capabilities"],
            "role_targets": spec["role_targets"],
            "priority": "primary",
            "routing_priority": spec.get("routing_priority", 20),
            "enabled": enabled,
            "requires_approval": False,
            "timeout_seconds": 180,
            "cost_tier": 0,
            "source": spec.get("source", "cli"),
        }
        adapters = _upsert_adapter(adapters, entry)
        print(
            f"- {name} enabled={enabled} details={details} "
            f"command={command or 'not-found'}"
        )

    payload["external_adapters"] = adapters
    adapters_path.write_text(json.dumps(payload, indent=2, ensure_ascii=True), encoding="utf-8")

    accounts_path = runtime_dir / "provider_accounts.json"
    accounts = _default_provider_accounts_template()
    for row in accounts["subscription_accounts"]:
        provider = str(row.get("provider", "")).strip().lower()
        spec = next((item for item in specs if item["provider"] == provider), None)
        if spec is None:
            continue
        command = _resolve_provider_command(spec)
        connected, details = _provider_runtime_health(spec, command)
        row["connected"] = connected
        row["details"] = details
    accounts_path.write_text(json.dumps(accounts, indent=2, ensure_ascii=True), encoding="utf-8")

    print(f"Provider connections updated: {adapters_path}")
    if missing:
        print(f"Missing required provider CLIs: {missing}")
        if strict:
            raise SystemExit(1)


def cmd_system_check(
    runtime_dir: Path,
    environment: str,
    browser_mode: str,
    doctor_timeout: int,
    strict: bool,
    min_skills_coverage: float,
) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir=runtime_dir,
        browser_mode=browser_mode,
        environment=environment,
    )
    summary = orchestrator.event_logger.summary()
    metrics = compute_pilot_metrics(orchestrator.taskboard.list_tasks(), summary)
    tool_integrator = AutoToolIntegrator(runtime_dir=runtime_dir, project_root=Path.cwd())
    mcp_report = tool_integrator.mcp_doctor(timeout=doctor_timeout, enable_healthy=False)
    skill_coverage = tool_integrator.skill_coverage(runtime_dir=runtime_dir)

    subscription_available = 0
    api_available = 0
    for adapter in orchestrator.router.adapters:
        if adapter.channel.value == "subscription" and adapter.available():
            subscription_available += 1
        if adapter.channel.value == "api" and adapter.available():
            api_available += 1

    checks = [
        (subscription_available >= 1, f"subscription_available={subscription_available}"),
        (mcp_report["healthy"] >= 1 or mcp_report["total"] == 0, f"mcp_healthy={mcp_report['healthy']}/{mcp_report['total']}"),
        (
            skill_coverage["coverage_percent"] >= min_skills_coverage,
            (
                f"skills_coverage={skill_coverage['coverage_percent']}% "
                f"required>={min_skills_coverage}%"
            ),
        ),
        (metrics["compliance_violations"] == 0, f"compliance_violations={metrics['compliance_violations']}"),
    ]

    print("System check:")
    print(f"- environment={environment}")
    print(
        f"- providers subscription_available={subscription_available} api_available={api_available}"
    )
    print(
        f"- pilot task_success={metrics['task_success_rate']}% "
        f"gates={metrics['gate_pass_rate']}% pro_share={metrics['pro_share_percent']}%"
    )
    print(
        f"- mcp healthy={mcp_report['healthy']}/{mcp_report['total']} enabled={mcp_report['enabled']}"
    )
    print(
        f"- skills_coverage={skill_coverage['coverage_percent']}% "
        f"({skill_coverage['skill_guidance_events']}/{skill_coverage['total_task_execution']})"
    )
    print(f"- alerts={summary.get('alerts', [])}")

    failed = [message for ok, message in checks if not ok]
    if failed:
        print("- checks_failed:")
        for item in failed:
            print(f"  - {item}")
    else:
        print("- checks_passed")

    report_path = runtime_dir / "system_check.json"
    payload = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "environment": environment,
        "providers": {
            "subscription_available": subscription_available,
            "api_available": api_available,
        },
        "pilot": metrics,
        "mcp": {
            "healthy": mcp_report["healthy"],
            "total": mcp_report["total"],
            "enabled": mcp_report["enabled"],
        },
        "skills_coverage": skill_coverage,
        "alerts": summary.get("alerts", []),
        "failed_checks": failed,
    }
    report_path.write_text(json.dumps(payload, indent=2, ensure_ascii=True), encoding="utf-8")
    print(f"- report={report_path}")

    if strict and failed:
        raise SystemExit(1)


def cmd_snapshot_create(runtime_dir: Path, label: str, max_keep: int) -> None:
    manager = SnapshotManager(project_root=Path.cwd())
    entry = manager.create_snapshot(label=label, max_keep=max_keep)
    print(
        f"Snapshot created: id={entry['id']} files={entry['file_count']} "
        f"size={entry['size_bytes']} label={entry['label']}"
    )


def cmd_snapshot_list() -> None:
    manager = SnapshotManager(project_root=Path.cwd())
    snapshots = manager.list_snapshots()
    if not snapshots:
        print("No snapshots available")
        return
    print(f"Snapshots: {len(snapshots)}")
    for item in snapshots[:50]:
        print(
            f"- {item.get('id')} created={item.get('created_at')} "
            f"files={item.get('file_count')} label={item.get('label','')}"
        )


def cmd_snapshot_restore(snapshot_id: str, no_backup: bool, dry_run: bool) -> None:
    manager = SnapshotManager(project_root=Path.cwd())
    if not snapshot_id.strip():
        raise SystemExit("snapshot-restore requires --snapshot-id")

    if not no_backup and not dry_run:
        backup = manager.create_snapshot(label=f"auto_backup_before_restore:{snapshot_id}")
        print(f"Backup snapshot created: {backup['id']}")

    result = manager.restore_snapshot(snapshot_id, dry_run=dry_run)
    print(
        f"Snapshot restore: id={result['snapshot_id']} restored_files={result['restored_files']} "
        f"dry_run={result['dry_run']}"
    )


def cmd_skills_coverage(runtime_dir: Path) -> None:
    integrator = AutoToolIntegrator(runtime_dir=runtime_dir, project_root=Path.cwd())
    coverage = integrator.skill_coverage(runtime_dir=runtime_dir)
    print("Skills coverage:")
    print(
        f"- guidance_events={coverage['skill_guidance_events']} "
        f"task_execution={coverage['total_task_execution']} "
        f"coverage_percent={coverage['coverage_percent']}"
    )


def cmd_dashboard(
    runtime_dir: Path,
    browser_mode: str,
    environment: str,
    output_path: Path,
    open_browser: bool,
) -> None:
    orchestrator = build_default_orchestrator(
        runtime_dir,
        browser_mode=browser_mode,
        environment=environment,
    )
    tasks = orchestrator.taskboard.list_tasks()
    summary = orchestrator.event_logger.summary()
    pilot_metrics = compute_pilot_metrics(tasks, summary)
    budget = orchestrator.router.budget_manager
    budget_snapshot = budget.snapshot() if budget is not None else None
    memory_counts = {
        agent: orchestrator.memory.count(agent)
        for agent in orchestrator.memory.list_agents()
    }

    payload = build_dashboard_payload(
        runtime_dir=runtime_dir,
        tasks=tasks,
        summary=summary,
        pilot_metrics=pilot_metrics,
        budget_snapshot=budget_snapshot,
        memory_counts=memory_counts,
    )
    html_content = render_dashboard_html(payload)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html_content, encoding="utf-8")
    print(f"Dashboard written: {output_path}")
    if open_browser:
        webbrowser.open(output_path.resolve().as_uri())
        print("Dashboard opened in browser")


def cmd_contract_first(runtime_dir: Path, epic_id: str, title: str, description: str) -> None:
    orchestrator = build_default_orchestrator(runtime_dir, environment="dev")
    lead = WorkTask(
        task_id=f"{epic_id}::lead",
        title=f"Plan {title}",
        description=description,
        role=Role.TEAM_LEAD,
    )
    researcher = WorkTask(
        task_id=f"{epic_id}::research",
        title=f"Research {title}",
        description="Explorar repositorio y preparar contrato tecnico.",
        role=Role.RESEARCHER,
        dependencies=[lead.task_id],
    )
    engineer = WorkTask(
        task_id=f"{epic_id}::implement",
        title=f"Implement {title}",
        description="Implementar contrato acordado por Team Lead y Researcher.",
        role=Role.ENGINEER,
        dependencies=[researcher.task_id],
        metadata={"required_capabilities": ["coding"]},
    )
    for task in (lead, researcher, engineer):
        if not orchestrator.taskboard.get_task(task.task_id):
            orchestrator.submit_task(task)

    orchestrator.mailbox.send(
        sender="team_lead",
        recipient="broadcast",
        subject=f"Contract-first spawned: {epic_id}",
        body=(
            "Fases creadas: lead -> research -> implement. "
            "Las gates de review/qa se abriran automaticamente en implementacion."
        ),
    )
    print(f"Contract-first pipeline creado para {epic_id}")


def main() -> None:
    _load_dotenv_if_present(Path(".env"))
    parser = argparse.ArgumentParser(description="AI Team Hybrid Orchestrator")
    parser.add_argument(
        "command",
        choices=[
            "init",
            "plan",
            "demo",
            "status",
            "pilot-check",
            "catalog-tools",
            "inventory-tools",
            "tool-catalog",
            "tool-sync",
            "skills-library",
            "skills-sync",
            "skills-coverage",
            "mcp-status",
            "mcp-doctor",
            "provider-status",
            "provider-connect",
            "provider-doctor",
            "system-check",
            "snapshot-create",
            "snapshot-list",
            "snapshot-restore",
            "dashboard",
            "run",
            "meeting",
            "memory",
            "exec",
            "adapters",
            "contract-first",
        ],
    )
    parser.add_argument("--runtime-dir", default="runtime", help="Runtime storage directory")
    parser.add_argument("--epic-id", default="EPIC-001", help="Epic ID for contract-first")
    parser.add_argument("--title", default="Nuevo flujo AI Team", help="Epic title")
    parser.add_argument(
        "--description",
        default="Plan e implementacion contract-first para el AI Team.",
        help="Epic description",
    )
    parser.add_argument("--rounds", type=int, default=10, help="Rounds for run command")
    parser.add_argument("--topic", default="Weekly Sync", help="Meeting topic")
    parser.add_argument("--agent", default="lead-1", help="Agent ID for memory command")
    parser.add_argument("--limit", type=int, default=10, help="Memory entries to print")
    parser.add_argument("--shell", choices=["cmd", "powershell"], default="cmd")
    parser.add_argument("--command-text", default="python --version", help="Command for exec")
    parser.add_argument("--min-task-success-rate", type=float, default=85.0)
    parser.add_argument("--min-gate-pass-rate", type=float, default=85.0)
    parser.add_argument("--min-pro-share", type=float, default=60.0)
    parser.add_argument("--max-compliance-violations", type=int, default=0)
    parser.add_argument(
        "--catalog-root",
        default=os.getenv("AITEAM_SHARED_TOOLS_ROOT", str(Path.cwd().parent)),
        help="Root directory to catalog external tools",
    )
    parser.add_argument("--catalog-limit", type=int, default=30, help="Max projects in catalog")
    parser.add_argument(
        "--inventory-output",
        default="runtime/tool_inventory.json",
        help="Output JSON path for inventory-tools",
    )
    parser.add_argument(
        "--tool-request-file",
        default="runtime/tool_requests.json",
        help="Input JSON with tool_requirements for tool-sync",
    )
    parser.add_argument(
        "--tool-catalog-file",
        default="config/tool_sources.catalog.json",
        help="Tool catalog JSON path",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Fail command when tool-sync reports errors",
    )
    parser.add_argument(
        "--allow-internet",
        action="store_true",
        help="Allow internet tool acquisition even in prod for tool-sync",
    )
    parser.add_argument(
        "--show-content",
        action="store_true",
        help="Show extended description output for catalog/library commands",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Force regeneration for commands that sync artifacts",
    )
    parser.add_argument(
        "--doctor-timeout",
        type=int,
        default=20,
        help="Timeout seconds for mcp-doctor probes",
    )
    parser.add_argument(
        "--enable-healthy",
        action="store_true",
        help="Enable MCP servers that pass mcp-doctor checks",
    )
    parser.add_argument(
        "--enable-sensitive",
        action="store_true",
        help="Allow mcp-doctor to auto-enable sensitive MCP servers",
    )
    parser.add_argument(
        "--min-skills-coverage",
        type=float,
        default=0.0,
        help="Minimum required skills guidance coverage for system-check",
    )
    parser.add_argument(
        "--snapshot-id",
        default="",
        help="Snapshot ID for snapshot-restore",
    )
    parser.add_argument(
        "--snapshot-label",
        default="",
        help="Optional label for snapshot-create",
    )
    parser.add_argument(
        "--snapshot-max-keep",
        type=int,
        default=30,
        help="Maximum number of snapshots to keep",
    )
    parser.add_argument(
        "--no-backup",
        action="store_true",
        help="Do not auto-create backup before snapshot restore",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview snapshot restore without writing files",
    )
    parser.add_argument(
        "--dashboard-output",
        default="runtime/dashboard.html",
        help="Output HTML path for dashboard command",
    )
    parser.add_argument(
        "--open-browser",
        action="store_true",
        help="Open dashboard output in browser",
    )
    parser.add_argument(
        "--browser-mode",
        choices=["basic", "playwright"],
        default=os.getenv("AITEAM_BROWSER_MODE", "basic"),
        help="Browser execution backend",
    )
    parser.add_argument(
        "--environment",
        choices=["dev", "stage", "prod"],
        default=os.getenv("AITEAM_ENV", "dev"),
        help="Compliance environment profile",
    )
    parser.add_argument(
        "--create-template",
        action="store_true",
        help="Create template file for adapters command",
    )
    args = parser.parse_args()

    runtime_dir = Path(args.runtime_dir)

    if args.command == "init":
        cmd_init(runtime_dir)
    elif args.command == "plan":
        cmd_plan()
    elif args.command == "demo":
        cmd_demo(runtime_dir, browser_mode=args.browser_mode, environment=args.environment)
    elif args.command == "status":
        cmd_status(runtime_dir, browser_mode=args.browser_mode, environment=args.environment)
    elif args.command == "contract-first":
        cmd_contract_first(
            runtime_dir=runtime_dir,
            epic_id=args.epic_id,
            title=args.title,
            description=args.description,
        )
    elif args.command == "run":
        cmd_run(
            runtime_dir=runtime_dir,
            rounds=args.rounds,
            browser_mode=args.browser_mode,
            environment=args.environment,
        )
    elif args.command == "pilot-check":
        cmd_pilot_check(
            runtime_dir=runtime_dir,
            browser_mode=args.browser_mode,
            environment=args.environment,
            min_task_success_rate=args.min_task_success_rate,
            min_gate_pass_rate=args.min_gate_pass_rate,
            min_pro_share=args.min_pro_share,
            max_compliance_violations=args.max_compliance_violations,
        )
    elif args.command == "catalog-tools":
        cmd_catalog_tools(catalog_root=Path(args.catalog_root), limit=args.catalog_limit)
    elif args.command == "inventory-tools":
        cmd_inventory_tools(
            catalog_root=Path(args.catalog_root),
            output_path=Path(args.inventory_output),
            limit=args.catalog_limit,
        )
    elif args.command == "tool-catalog":
        cmd_tool_catalog(catalog_path=Path(args.tool_catalog_file), limit=args.catalog_limit)
    elif args.command == "tool-sync":
        cmd_tool_sync(
            runtime_dir=runtime_dir,
            environment=args.environment,
            request_path=Path(args.tool_request_file),
            catalog_path=Path(args.tool_catalog_file),
            strict=args.strict,
            allow_internet=args.allow_internet,
        )
    elif args.command == "skills-library":
        cmd_skills_library(runtime_dir=runtime_dir, show_content=args.show_content)
    elif args.command == "skills-sync":
        cmd_skills_sync(runtime_dir=runtime_dir, force=args.force)
    elif args.command == "skills-coverage":
        cmd_skills_coverage(runtime_dir=runtime_dir)
    elif args.command == "mcp-status":
        cmd_mcp_status(runtime_dir=runtime_dir)
    elif args.command == "mcp-doctor":
        cmd_mcp_doctor(
            runtime_dir=runtime_dir,
            timeout=args.doctor_timeout,
            enable_healthy=args.enable_healthy,
            enable_sensitive=args.enable_sensitive,
        )
    elif args.command == "provider-status":
        cmd_provider_status(runtime_dir=runtime_dir, environment=args.environment)
    elif args.command == "provider-connect":
        cmd_provider_connect(runtime_dir=runtime_dir, strict=args.strict)
    elif args.command == "provider-doctor":
        cmd_provider_doctor(runtime_dir=runtime_dir, strict=args.strict)
    elif args.command == "system-check":
        cmd_system_check(
            runtime_dir=runtime_dir,
            environment=args.environment,
            browser_mode=args.browser_mode,
            doctor_timeout=args.doctor_timeout,
            strict=args.strict,
            min_skills_coverage=args.min_skills_coverage,
        )
    elif args.command == "snapshot-create":
        cmd_snapshot_create(
            runtime_dir=runtime_dir,
            label=args.snapshot_label,
            max_keep=args.snapshot_max_keep,
        )
    elif args.command == "snapshot-list":
        cmd_snapshot_list()
    elif args.command == "snapshot-restore":
        cmd_snapshot_restore(
            snapshot_id=args.snapshot_id,
            no_backup=args.no_backup,
            dry_run=args.dry_run,
        )
    elif args.command == "dashboard":
        cmd_dashboard(
            runtime_dir=runtime_dir,
            browser_mode=args.browser_mode,
            environment=args.environment,
            output_path=Path(args.dashboard_output),
            open_browser=args.open_browser,
        )
    elif args.command == "meeting":
        cmd_meeting(
            runtime_dir=runtime_dir,
            topic=args.topic,
            browser_mode=args.browser_mode,
            environment=args.environment,
        )
    elif args.command == "memory":
        cmd_memory(runtime_dir=runtime_dir, agent=args.agent, limit=args.limit)
    elif args.command == "exec":
        cmd_exec(
            runtime_dir=runtime_dir,
            shell=args.shell,
            command=args.command_text,
            browser_mode=args.browser_mode,
            environment=args.environment,
        )
    elif args.command == "adapters":
        cmd_adapters(runtime_dir=runtime_dir, create_template=args.create_template)


if __name__ == "__main__":
    main()

from __future__ import annotations

import html
import json
from collections import Counter
from pathlib import Path
from typing import Any

from aiteam.types import WorkTask


def build_dashboard_payload(
    *,
    runtime_dir: Path,
    tasks: list[WorkTask],
    summary: dict[str, Any],
    pilot_metrics: dict[str, float | int],
    budget_snapshot: dict[str, Any] | None,
    memory_counts: dict[str, int],
) -> dict[str, Any]:
    state_counts = Counter(task.state.value for task in tasks)
    role_counts = Counter(task.role.value for task in tasks)

    return {
        "runtime_dir": str(runtime_dir.resolve()),
        "task_total": len(tasks),
        "task_state_counts": dict(state_counts),
        "task_role_counts": dict(role_counts),
        "summary": summary,
        "pilot_metrics": pilot_metrics,
        "budget": budget_snapshot or {},
        "memory_counts": memory_counts,
        "tasks": [_task_row(task) for task in tasks],
        "recent_events": _recent_events(runtime_dir / "events.jsonl", limit=30),
    }


def render_dashboard_html(payload: dict[str, Any]) -> str:
    summary = payload.get("summary", {})
    pilot = payload.get("pilot_metrics", {})
    budget = payload.get("budget", {})

    cards = [
        ("Tasks", str(payload.get("task_total", 0))),
        ("Execution Success", f"{summary.get('task_execution_success_rate', 0)}%"),
        ("Pro Share", f"{pilot.get('pro_share_percent', 0)}%"),
        ("API Share", f"{summary.get('api_share_percent', 0)}%"),
        ("Compliance Violations", str(summary.get("compliance_violations", 0))),
        (
            "Daily Budget",
            f"${budget.get('daily_api_spend_usd', 0)}/${budget.get('daily_api_budget_usd', 0)}",
        ),
    ]

    tasks_rows = "\n".join(
        "<tr>"
        f"<td>{html.escape(item['task_id'])}</td>"
        f"<td>{html.escape(item['state'])}</td>"
        f"<td>{html.escape(item['role'])}</td>"
        f"<td>{html.escape(item['assignee'])}</td>"
        f"<td>{html.escape(item['title'])}</td>"
        "</tr>"
        for item in payload.get("tasks", [])
    )

    event_rows = "\n".join(
        "<tr>"
        f"<td>{html.escape(str(item.get('ts', '')))}</td>"
        f"<td>{html.escape(str(item.get('event_type', '')))}</td>"
        f"<td>{html.escape(_compact_json(item.get('payload', {}), 180))}</td>"
        "</tr>"
        for item in payload.get("recent_events", [])
    )

    alerts = payload.get("summary", {}).get("alerts", [])
    alert_items = "\n".join(f"<li>{html.escape(str(alert))}</li>" for alert in alerts)
    if not alert_items:
        alert_items = "<li>none</li>"

    state_items = _kv_list(payload.get("task_state_counts", {}))
    role_items = _kv_list(payload.get("task_role_counts", {}))
    channel_items = _kv_list(payload.get("summary", {}).get("channels", {}))
    provider_items = _kv_list(payload.get("summary", {}).get("providers", {}))
    memory_items = _kv_list(payload.get("memory_counts", {}))

    card_html = "\n".join(
        "<div class='card'>"
        f"<div class='label'>{html.escape(label)}</div>"
        f"<div class='value'>{html.escape(value)}</div>"
        "</div>"
        for label, value in cards
    )

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>AI Team Dashboard</title>
  <style>
    :root {{
      --bg: #f4f6f8;
      --surface: #ffffff;
      --ink: #12212f;
      --muted: #5f7182;
      --accent: #006f8a;
      --line: #d8e1e8;
    }}
    body {{ margin: 0; font-family: "Segoe UI", "Helvetica Neue", sans-serif; background: var(--bg); color: var(--ink); }}
    .wrap {{ max-width: 1200px; margin: 0 auto; padding: 20px; }}
    h1 {{ margin: 0 0 10px; font-size: 28px; }}
    .sub {{ color: var(--muted); margin-bottom: 18px; }}
    .cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 10px; margin-bottom: 16px; }}
    .card {{ background: var(--surface); border: 1px solid var(--line); border-radius: 10px; padding: 12px; }}
    .label {{ color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: 0.04em; }}
    .value {{ margin-top: 6px; font-weight: 700; font-size: 20px; }}
    .grid {{ display: grid; gap: 12px; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); margin-bottom: 16px; }}
    .panel {{ background: var(--surface); border: 1px solid var(--line); border-radius: 10px; padding: 12px; }}
    .panel h2 {{ margin: 0 0 8px; font-size: 16px; color: var(--accent); }}
    ul {{ margin: 0; padding-left: 18px; }}
    li {{ margin-bottom: 4px; }}
    table {{ width: 100%; border-collapse: collapse; background: var(--surface); border: 1px solid var(--line); border-radius: 10px; overflow: hidden; }}
    th, td {{ border-bottom: 1px solid var(--line); padding: 8px; text-align: left; font-size: 13px; vertical-align: top; }}
    th {{ background: #edf3f7; }}
    .table-title {{ margin: 16px 0 8px; color: var(--accent); font-size: 16px; }}
  </style>
</head>
<body>
  <div class="wrap">
    <h1>AI Team Operations Dashboard</h1>
    <div class="sub">runtime: {html.escape(str(payload.get('runtime_dir', '')))}</div>
    <div class="cards">{card_html}</div>
    <div class="grid">
      <section class="panel"><h2>Alerts</h2><ul>{alert_items}</ul></section>
      <section class="panel"><h2>Task States</h2><ul>{state_items}</ul></section>
      <section class="panel"><h2>Roles</h2><ul>{role_items}</ul></section>
      <section class="panel"><h2>Channels</h2><ul>{channel_items}</ul></section>
      <section class="panel"><h2>Providers</h2><ul>{provider_items}</ul></section>
      <section class="panel"><h2>Memory Entries</h2><ul>{memory_items}</ul></section>
    </div>

    <div class="table-title">Tasks</div>
    <table>
      <thead><tr><th>ID</th><th>State</th><th>Role</th><th>Assignee</th><th>Title</th></tr></thead>
      <tbody>{tasks_rows}</tbody>
    </table>

    <div class="table-title">Recent Events</div>
    <table>
      <thead><tr><th>Timestamp</th><th>Type</th><th>Payload</th></tr></thead>
      <tbody>{event_rows}</tbody>
    </table>
  </div>
</body>
</html>
"""


def _task_row(task: WorkTask) -> dict[str, str]:
    return {
        "task_id": task.task_id,
        "state": task.state.value,
        "role": task.role.value,
        "assignee": task.assignee or "",
        "title": task.title,
    }


def _recent_events(path: Path, limit: int) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    items: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(record, dict):
            items.append(record)
    return items[-max(1, limit) :]


def _kv_list(items: dict[str, Any]) -> str:
    if not items:
        return "<li>none</li>"
    return "\n".join(
        f"<li><strong>{html.escape(str(key))}</strong>: {html.escape(str(value))}</li>"
        for key, value in sorted(items.items(), key=lambda kv: str(kv[0]))
    )


def _compact_json(value: Any, max_chars: int) -> str:
    text = json.dumps(value, ensure_ascii=True)
    if len(text) <= max_chars:
        return text
    if max_chars <= 3:
        return text[:max_chars]
    return text[: max_chars - 3] + "..."

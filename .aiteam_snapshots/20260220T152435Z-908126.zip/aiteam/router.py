from __future__ import annotations

from dataclasses import dataclass

from aiteam.adapters.base import ModelAdapter
from aiteam.config import RouterPolicy
from aiteam.finops import BudgetManager
from aiteam.observability import EventLogger
from aiteam.types import ChannelType, Complexity, Criticality, RoutingDecision, RoutingRequest


@dataclass
class AdapterAttempt:
    adapter_name: str
    channel: ChannelType
    success: bool
    error: str | None


class HybridRouter:
    """Router Pro-first con fallback API."""

    def __init__(
        self,
        adapters: list[ModelAdapter],
        policy: RouterPolicy,
        budget_manager: BudgetManager | None = None,
        event_logger: EventLogger | None = None,
    ) -> None:
        self.adapters = adapters
        self.policy = policy
        self.budget_manager = budget_manager
        self.event_logger = event_logger

    def _eligible(self, request: RoutingRequest) -> list[ModelAdapter]:
        eligible = []
        for adapter in self.adapters:
            if adapter.role_targets and request.role.value not in adapter.role_targets:
                continue
            if adapter.requires_approval and not (
                request.sensitive_approval or adapter.name in request.approved_adapters
            ):
                continue
            if request.required_capabilities and not request.required_capabilities.issubset(
                adapter.capabilities
            ):
                continue
            if not adapter.available():
                continue
            eligible.append(adapter)
        return eligible

    def _sort_adapters(self, adapters: list[ModelAdapter]) -> list[ModelAdapter]:
        provider_priority_sub = {
            provider: i
            for i, provider in enumerate(self.policy.preferred_subscription_providers)
        }
        provider_priority_api = {
            provider: i for i, provider in enumerate(self.policy.preferred_api_providers)
        }

        def key(adapter: ModelAdapter) -> tuple[int, int, int, int, str]:
            if adapter.channel == ChannelType.SUBSCRIPTION:
                provider_rank = provider_priority_sub.get(adapter.provider, 99)
                channel_rank = 0 if self.policy.pro_first else 1
            else:
                provider_rank = provider_priority_api.get(adapter.provider, 99)
                channel_rank = 1 if self.policy.pro_first else 0
            return (
                channel_rank,
                adapter.routing_priority,
                provider_rank,
                adapter.cost_tier,
                adapter.name,
            )

        return sorted(adapters, key=key)

    def _must_include_api(self, request: RoutingRequest) -> bool:
        return (
            request.complexity == Complexity.HIGH
            or request.criticality == Criticality.HIGH
            or not self.policy.pro_first
        )

    def route_and_invoke(self, request: RoutingRequest, prompt: str) -> RoutingDecision:
        attempts: list[str] = []
        attempted_channels: dict[ChannelType, int] = {
            ChannelType.SUBSCRIPTION: 0,
            ChannelType.API: 0,
        }

        eligible = self._sort_adapters(self._eligible(request))
        if not eligible:
            decision = RoutingDecision(
                success=False,
                provider="none",
                model="none",
                channel=ChannelType.API,
                reason="no_eligible_adapter",
                response=self._failed_response("No adapters available"),
                attempts=attempts,
            )
            self._record_decision(decision)
            return decision

        must_include_api = self._must_include_api(request)
        api_attempt_limit = self.policy.max_api_attempts
        max_api_cost_tier = 999
        if self.budget_manager is not None:
            signal = self.budget_manager.api_signal()
            api_attempt_limit = min(api_attempt_limit, signal.suggested_max_api_attempts)
            max_api_cost_tier = signal.max_api_cost_tier

        for adapter in eligible:
            if adapter.channel == ChannelType.SUBSCRIPTION:
                if attempted_channels[ChannelType.SUBSCRIPTION] >= self.policy.max_subscription_attempts:
                    continue
            else:
                if not self.policy.api_fallback_enabled:
                    continue
                if self.budget_manager is not None:
                    signal = self.budget_manager.api_signal()
                    if not signal.can_use_api:
                        attempts.append(f"api_budget_block:{signal.reason}")
                        continue
                    if adapter.cost_tier > signal.max_api_cost_tier:
                        attempts.append(
                            f"api_tier_block:{adapter.name}:tier{adapter.cost_tier}>max{signal.max_api_cost_tier}"
                        )
                        continue
                if (
                    not must_include_api
                    and attempted_channels[ChannelType.SUBSCRIPTION] == 0
                    and self.policy.pro_first
                ):
                    continue
                if attempted_channels[ChannelType.API] >= api_attempt_limit:
                    continue

            attempted_channels[adapter.channel] += 1
            response = adapter.invoke(prompt)
            attempts.append(
                f"{adapter.name}:{adapter.channel.value}:{'ok' if response.success else 'fail'}"
            )
            if response.success:
                decision = RoutingDecision(
                    success=True,
                    provider=adapter.provider,
                    model=adapter.model,
                    channel=adapter.channel,
                    reason="selected_by_policy",
                    response=response,
                    attempts=attempts,
                )
                self._record_decision(decision)
                return decision

        decision = RoutingDecision(
            success=False,
            provider="none",
            model="none",
            channel=ChannelType.API,
            reason="all_attempts_failed",
            response=self._failed_response("All adapter attempts failed"),
            attempts=attempts,
        )
        self._record_decision(decision)
        return decision

    @staticmethod
    def _failed_response(message: str):
        from aiteam.types import AdapterResponse

        return AdapterResponse(success=False, content="", error=message, latency_ms=0)

    def _record_decision(self, decision: RoutingDecision) -> None:
        if self.budget_manager is not None:
            self.budget_manager.record_routing_decision(decision)
        if self.event_logger is not None:
            self.event_logger.emit(
                "routing_decision",
                {
                    "success": decision.success,
                    "provider": decision.provider,
                    "model": decision.model,
                    "channel": decision.channel.value,
                    "reason": decision.reason,
                    "attempts": decision.attempts,
                },
            )

from __future__ import annotations

from dataclasses import dataclass

from aiteam.types import Role


@dataclass(frozen=True)
class AgentProfile:
    role: Role
    system_prompt: str


DEFAULT_PROFILES: dict[Role, AgentProfile] = {
    Role.TEAM_LEAD: AgentProfile(
        role=Role.TEAM_LEAD,
        system_prompt=(
            "Eres Team Lead. Descompone objetivos, controla dependencias y define el minimo cambio "
            "necesario para entregar valor sin sobreingenieria."
        ),
    ),
    Role.RESEARCHER: AgentProfile(
        role=Role.RESEARCHER,
        system_prompt=(
            "Eres Researcher. Prioriza evidencia de codigo y riesgos. Entrega hallazgos accionables, "
            "no teoria extensa."
        ),
    ),
    Role.ENGINEER: AgentProfile(
        role=Role.ENGINEER,
        system_prompt=(
            "Eres Engineer. Implementa cambios pequenos, coherentes y testeables. Respeta contratos y "
            "evita romper compatibilidad."
        ),
    ),
    Role.REVIEWER: AgentProfile(
        role=Role.REVIEWER,
        system_prompt=(
            "Eres Reviewer. Busca defectos de logica, seguridad, mantenibilidad y deuda tecnica evitable."
        ),
    ),
    Role.QA: AgentProfile(
        role=Role.QA,
        system_prompt=(
            "Eres QA. Define validaciones de regresion y criterios de salida claros para aprobar o rechazar."
        ),
    ),
}


def build_prompt(role: Role, task_title: str, task_description: str) -> str:
    profile = DEFAULT_PROFILES[role]
    return (
        f"{profile.system_prompt}\n"
        f"Tarea: {task_title}\n"
        f"Descripcion: {task_description}\n"
        "Entrega: pasos concretos, decision y riesgos."
    )

from __future__ import annotations

from dataclasses import dataclass

from aiteam.mailbox import Mailbox
from aiteam.memory import AgentMemoryStore
from aiteam.observability import EventLogger


@dataclass
class MeetingParticipant:
    agent_id: str
    role: str


class TeamCommunicator:
    def __init__(
        self,
        mailbox: Mailbox,
        memory: AgentMemoryStore,
        event_logger: EventLogger | None = None,
    ) -> None:
        self.mailbox = mailbox
        self.memory = memory
        self.event_logger = event_logger

    def send_dm(
        self,
        sender: str,
        recipient: str,
        subject: str,
        body: str,
        task_id: str | None = None,
    ) -> None:
        self.mailbox.send(
            sender=sender,
            recipient=recipient,
            subject=subject,
            body=body,
            task_id=task_id,
        )
        self._event(
            "mail_dm",
            {
                "sender": sender,
                "recipient": recipient,
                "subject": subject,
                "task_id": task_id,
            },
        )

    def broadcast(
        self,
        sender: str,
        subject: str,
        body: str,
        task_id: str | None = None,
    ) -> None:
        self.mailbox.send(
            sender=sender,
            recipient="broadcast",
            subject=subject,
            body=body,
            task_id=task_id,
        )
        self._event(
            "mail_broadcast",
            {"sender": sender, "subject": subject, "task_id": task_id},
        )

    def run_sync_meeting(
        self,
        topic: str,
        participants: list[MeetingParticipant],
        task_id: str | None = None,
    ) -> str:
        lines = [f"Meeting Topic: {topic}"]
        for participant in participants:
            standup = self._standup_line(participant)
            lines.append(standup)

        minutes = "\n".join(lines)
        self.broadcast(
            sender="meeting-bot",
            subject=f"Sync meeting: {topic}",
            body=minutes,
            task_id=task_id,
        )

        for participant in participants:
            self.memory.remember(
                agent_id=participant.agent_id,
                role=participant.role,
                kind="meeting_minutes",
                content=minutes,
                task_id=task_id,
                tags=["meeting", "sync"],
            )

        self._event(
            "sync_meeting",
            {
                "topic": topic,
                "participants": [f"{p.role}:{p.agent_id}" for p in participants],
                "task_id": task_id,
            },
        )
        return minutes

    def _standup_line(self, participant: MeetingParticipant) -> str:
        recent = self.memory.recent(
            participant.agent_id,
            limit=4,
            exclude_kinds={"meeting_minutes"},
        )
        if not recent:
            return f"- {participant.role}/{participant.agent_id}: sin novedades registradas."

        chunks = []
        for item in recent:
            text = item.content.strip().replace("\n", " ")
            text = text[:120]
            chunks.append(f"[{item.kind}] {text}")

        return f"- {participant.role}/{participant.agent_id}: " + " | ".join(chunks)

    def _event(self, event_type: str, payload: dict) -> None:
        if self.event_logger is not None:
            self.event_logger.emit(event_type, payload)

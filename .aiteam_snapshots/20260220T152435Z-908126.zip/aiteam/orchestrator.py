from __future__ import annotations

import os
from pathlib import Path

from aiteam.adapters.registry import load_external_adapters
from aiteam.autotools import AutoToolIntegrator, ToolIntegrationReport
from aiteam.communication import MeetingParticipant, TeamCommunicator
from aiteam.compliance import ComplianceGuard, CompliancePolicy
from aiteam.execution import (
    BrowserController,
    CommandPolicy,
    ExecutionEngine,
    LocalCommandExecutor,
    PlaywrightBrowserController,
)
from aiteam.mailbox import Mailbox
from aiteam.memory import AgentMemoryStore
from aiteam.observability import EventLogger
from aiteam.profiles import build_prompt
from aiteam.router import HybridRouter
from aiteam.runtime import SandboxManager
from aiteam.taskboard import TaskBoard
from aiteam.types import Role, RoutingDecision, RoutingRequest, TaskState, WorkTask


class AITeamOrchestrator:
    def __init__(
        self,
        router: HybridRouter,
        runtime_dir: Path,
        project_root: Path | None = None,
        additional_workspace_roots: list[Path] | None = None,
        browser_mode: str = "basic",
        environment: str = "dev",
    ) -> None:
        self.router = router
        self.runtime_dir = runtime_dir
        self.taskboard = TaskBoard(runtime_dir / "tasks.json")
        self.mailbox = Mailbox(runtime_dir / "mailbox.jsonl")
        self.sandboxes = SandboxManager(runtime_dir / "sandboxes")
        self.event_logger = EventLogger(runtime_dir)
        self.project_root = (project_root or runtime_dir.parent).resolve()
        self.additional_workspace_roots = [
            path.resolve() for path in (additional_workspace_roots or [])
        ]
        self.environment = environment
        self.compliance = ComplianceGuard(policy=CompliancePolicy(environment=environment))
        self.memory = AgentMemoryStore(runtime_dir / "memory")
        self.communicator = TeamCommunicator(
            mailbox=self.mailbox,
            memory=self.memory,
            event_logger=self.event_logger,
        )
        self.execution = ExecutionEngine(
            executor=LocalCommandExecutor(
                workspace_root=self.project_root,
                policy=CommandPolicy(),
                additional_roots=self.additional_workspace_roots,
            ),
            browser=(
                PlaywrightBrowserController()
                if browser_mode.strip().lower() == "playwright"
                else BrowserController()
            ),
            event_logger=self.event_logger,
        )
        self.tool_integrator = AutoToolIntegrator(
            runtime_dir=self.runtime_dir,
            project_root=self.project_root,
        )
        self.tool_integrator.sync_skill_library(force=False)
        self._round = 0
        self._last_event_meeting_round: dict[str, int] = {}
        self.agent_pools = self._build_agent_pools()

    def submit_task(self, task: WorkTask) -> None:
        self.taskboard.add_task(task)
        self.mailbox.send(
            sender="system",
            recipient="team_lead",
            subject=f"Nueva tarea: {task.task_id}",
            body=f"{task.title}",
            task_id=task.task_id,
        )
        self.memory.remember(
            agent_id="lead-1",
            role=Role.TEAM_LEAD.value,
            kind="task_submitted",
            content=f"{task.task_id}: {task.title}",
            task_id=task.task_id,
            tags=["task", "inbox"],
        )

    def process_once(self) -> int:
        processed = 0
        for task in self.taskboard.ready_tasks():
            assignee = task.assignee or self._assignee_for_role(task.role)
            if not self.taskboard.claim_task(task.task_id, assignee=assignee):
                current = self.taskboard.get_task(task.task_id)
                if current is not None and current.state == TaskState.BLOCKED:
                    self._maybe_run_event_meeting(
                        trigger="file_conflict",
                        task_id=task.task_id,
                        reason=str(current.metadata.get("blocked_by_files", [])),
                    )
                continue
            self._run_task(task)
            processed += 1
        self._release_blocked_parent_tasks()
        if processed > 0:
            self._round += 1
            self._run_round_sync_meeting()
        return processed

    def run_until_idle(self, max_rounds: int = 10) -> None:
        for _ in range(max_rounds):
            processed = self.process_once()
            if processed == 0:
                break

    def _run_task(self, task: WorkTask) -> None:
        assignee = task.assignee or self._assignee_for_role(task.role)
        workspace = self.sandboxes.task_workspace(agent_id=assignee, task_id=task.task_id)

        sensitive_approval, approval_reason = self.compliance.evaluate_sensitive_approval(task.metadata)
        tool_report = self._integrate_tools_for_task(
            task=task,
            assignee=assignee,
            internet_allowed=(self.environment != "prod" or sensitive_approval),
        )
        if not tool_report.success:
            self._fail_task_due_to_compliance(
                task=task,
                assignee=assignee,
                reason="tool_integration_failed",
                details=tool_report.errors,
            )
            return
        if tool_report.integrated_adapters:
            self._sync_router_external_adapters()

        execution_plan = task.metadata.get("execution_plan", [])
        execution_context = ""
        if isinstance(execution_plan, list) and execution_plan:
            allowed, reason, sensitive_commands = self.compliance.validate_execution_plan(
                execution_plan,
                task.metadata,
            )
            if not allowed:
                self._fail_task_due_to_compliance(
                    task=task,
                    assignee=assignee,
                    reason=reason,
                    details=sensitive_commands,
                )
                return
            if sensitive_commands:
                self.event_logger.emit(
                    "compliance_sensitive_plan",
                    {
                        "task_id": task.task_id,
                        "assignee": assignee,
                        "environment": self.environment,
                        "approved": True,
                        "steps": [self.compliance.redact_text(item)[:160] for item in sensitive_commands],
                    },
                )
            step_results = self.execution.execute_plan(
                task_id=task.task_id,
                plan=execution_plan,
                workspace=workspace,
            )
            execution_context = self._compose_execution_context(step_results)
            self.memory.remember(
                agent_id=assignee,
                role=task.role.value,
                kind="execution_plan_result",
                content=execution_context,
                task_id=task.task_id,
                tags=["execution", "environment"],
            )

        context = self._build_collaboration_context(task=task, assignee=assignee)
        peer_context = self._run_peer_consultation(task=task, assignee=assignee)
        skill_mcp_context = self._build_skill_mcp_context(task=task, assignee=assignee)

        prompt = build_prompt(task.role, task.title, task.description)
        if context:
            prompt = f"{prompt}\n\nContexto de equipo:\n{context}"
        if peer_context:
            prompt = f"{prompt}\n\nConsulta entre pares:\n{peer_context}"
        if skill_mcp_context:
            prompt = f"{prompt}\n\nSkills/MCP relevantes:\n{skill_mcp_context}"
        if execution_context:
            prompt = f"{prompt}\n\nResultados de ejecucion:\n{execution_context}"

        requested_approved_adapters = task.metadata.get("approved_adapters", [])
        if requested_approved_adapters and not sensitive_approval:
            self._fail_task_due_to_compliance(
                task=task,
                assignee=assignee,
                reason=approval_reason,
                details=["approved_adapters_requires_sensitive_approval"],
            )
            return

        request = RoutingRequest(
            role=task.role,
            complexity=task.complexity,
            criticality=task.criticality,
            required_capabilities=set(task.metadata.get("required_capabilities", [])),
            approved_adapters=self.compliance.approved_adapters(task.metadata),
            sensitive_approval=sensitive_approval,
        )
        decision = self.router.route_and_invoke(request=request, prompt=prompt)
        if (
            not decision.success
            and decision.reason == "no_eligible_adapter"
            and self._to_bool(task.metadata.get("auto_discover_tools", True))
        ):
            suggestion_report = self._auto_discover_tools(
                task=task,
                assignee=assignee,
                internet_allowed=(self.environment != "prod" or sensitive_approval),
            )
            if suggestion_report.integrated_adapters:
                self._sync_router_external_adapters()
                decision = self.router.route_and_invoke(request=request, prompt=prompt)

        self.event_logger.emit(
            "task_execution",
            {
                "task_id": task.task_id,
                "role": task.role.value,
                "assignee": assignee,
                "success": decision.success,
                "provider": decision.provider,
                "model": decision.model,
                "channel": decision.channel.value,
            },
        )

        if decision.success:
            safe_content = self.compliance.redact_text(decision.response.content)
            self.memory.remember(
                agent_id=assignee,
                role=task.role.value,
                kind="task_success",
                content=safe_content,
                task_id=task.task_id,
                tags=["result", decision.channel.value],
            )
            if self._should_open_quality_gates(task):
                self._spawn_quality_gates(task)
                self.taskboard.mark_blocked(
                    task.task_id,
                    reason="waiting_quality_gates",
                )
                self.communicator.broadcast(
                    sender=task.role.value,
                    subject=f"Quality gates opened: {task.task_id}",
                    body="Se crean tareas de review y QA antes de cerrar la tarea principal.",
                    task_id=task.task_id,
                )
                self._maybe_run_event_meeting(
                    trigger="quality_gate_opened",
                    task_id=task.task_id,
                    reason="review_qa_required",
                )
                return

            self.taskboard.mark_completed(task.task_id, details=safe_content)
            self.mailbox.send(
                sender=task.role.value,
                recipient="team_lead",
                subject=f"Task completed: {task.task_id}",
                body=(
                    f"provider={decision.provider} model={decision.model} "
                    f"channel={decision.channel.value} attempts={decision.attempts}"
                ),
                task_id=task.task_id,
            )
            self._notify_dependents(task.task_id, summary=safe_content)
            return

        failure_text = self.compliance.redact_text(decision.response.error or decision.reason)
        if self._maybe_handoff_and_retry(task=task, failed_assignee=assignee, decision=decision):
            return

        self.memory.remember(
            agent_id=assignee,
            role=task.role.value,
            kind="task_failure",
            content=failure_text,
            task_id=task.task_id,
            tags=["failure"],
        )
        self.taskboard.mark_failed(task.task_id, error=failure_text)
        self._maybe_run_event_meeting(
            trigger="task_failed",
            task_id=task.task_id,
            reason=failure_text,
        )
        self.mailbox.send(
            sender=task.role.value,
            recipient="team_lead",
            subject=f"Task failed: {task.task_id}",
            body=(
                f"reason={decision.reason} error={decision.response.error} "
                f"attempts={decision.attempts}"
            ),
            task_id=task.task_id,
        )

    def _build_agent_pools(self) -> dict[Role, list[str]]:
        defaults: dict[Role, list[str]] = {
            Role.TEAM_LEAD: ["lead-1", "lead-2"],
            Role.RESEARCHER: ["research-1", "research-2"],
            Role.ENGINEER: ["eng-1", "eng-2", "eng-3"],
            Role.REVIEWER: ["review-1", "review-2"],
            Role.QA: ["qa-1", "qa-2"],
        }
        pools: dict[Role, list[str]] = {}
        for role, fallback in defaults.items():
            env_key = f"AITEAM_ROLE_{role.value.upper()}_POOL"
            raw = os.getenv(env_key, "").strip()
            if not raw:
                pools[role] = fallback
                continue
            values = [item.strip() for item in raw.split(",") if item.strip()]
            pools[role] = values or fallback
        return pools

    def _assignee_for_role(self, role: Role, avoid: set[str] | None = None) -> str:
        blocked = {item.strip().lower() for item in (avoid or set()) if item.strip()}
        candidates = self.agent_pools.get(role, [])
        for candidate in candidates:
            if candidate.lower() in blocked:
                continue
            if self._agent_enabled(candidate):
                return candidate
        return candidates[0] if candidates else "lead-1"

    @staticmethod
    def _agent_enabled(agent_id: str) -> bool:
        key = f"AITEAM_AGENT_{agent_id.upper().replace('-', '_')}_ENABLED"
        value = os.getenv(key, "1").strip().lower()
        return value not in {"0", "false", "no", "off"}

    def _maybe_handoff_and_retry(
        self,
        *,
        task: WorkTask,
        failed_assignee: str,
        decision: RoutingDecision,
    ) -> bool:
        if task.metadata.get("skip_handoff_failover"):
            return False

        retry_count = int(task.metadata.get("retry_count", 0))
        max_handoffs = int(task.metadata.get("max_handoff_retries", 1))
        if retry_count >= max_handoffs:
            return False

        if not self._is_model_or_runtime_failure(decision):
            return False

        history = task.metadata.get("handoff_history", [])
        blocked = {failed_assignee}
        if isinstance(history, list):
            blocked.update(str(item).strip() for item in history if str(item).strip())
        substitute = self._assignee_for_role(task.role, avoid=blocked)
        if not substitute or substitute == failed_assignee:
            return False

        handoff_context = self._build_handoff_context(task=task, source_agent=failed_assignee)
        self.memory.remember(
            agent_id=substitute,
            role=task.role.value,
            kind="handoff_context",
            content=handoff_context,
            task_id=task.task_id,
            tags=["handoff", "continuity"],
        )
        self.mailbox.send(
            sender=failed_assignee,
            recipient=substitute,
            subject=f"Handoff required: {task.task_id}",
            body=handoff_context,
            task_id=task.task_id,
        )

        new_history = sorted(blocked)
        self.taskboard.update_metadata(
            task.task_id,
            {
                "handoff_history": new_history,
                "handoff_from": failed_assignee,
                "handoff_to": substitute,
                "handoff_reason": decision.response.error or decision.reason,
            },
        )
        self.taskboard.retry_task(
            task.task_id,
            reason=f"handoff:{failed_assignee}->{substitute}",
            assignee=substitute,
        )
        self.event_logger.emit(
            "agent_handoff",
            {
                "task_id": task.task_id,
                "role": task.role.value,
                "from": failed_assignee,
                "to": substitute,
                "reason": decision.response.error or decision.reason,
                "attempts": decision.attempts,
            },
        )
        return True

    @staticmethod
    def _is_model_or_runtime_failure(decision: RoutingDecision) -> bool:
        reason = (decision.reason or "").strip().lower()
        error = (decision.response.error or "").strip().lower()
        attempts = " ".join(decision.attempts).lower()
        blob = " ".join([reason, error, attempts])
        markers = [
            "all_attempts_failed",
            "no_eligible_adapter",
            "quota",
            "limit",
            "timeout",
            "unavailable",
            "forced_api_fallback",
            "external_exec_error",
            "command_not_found",
            "api_budget_block",
        ]
        return any(marker in blob for marker in markers)

    def _build_handoff_context(self, task: WorkTask, source_agent: str) -> str:
        excluded = {"meeting_minutes"}
        recent = self.memory.recent(source_agent, limit=5, exclude_kinds=excluded)
        relevant = self.memory.relevant(
            source_agent,
            f"{task.title}\n{task.description}",
            limit=4,
            exclude_kinds=excluded,
        )
        lines = [
            f"Task: {task.task_id} {task.title}",
            f"Descripcion: {self._compact_text(task.description, 180)}",
            "Contexto transferido:",
        ]
        seen: set[str] = set()
        for entry in relevant + recent:
            token = f"{entry.kind}|{entry.content}"[:300]
            if token in seen:
                continue
            seen.add(token)
            lines.append(f"- [{entry.kind}] {self._compact_text(entry.content, 180)}")
        if len(lines) == 3:
            lines.append("- Sin memoria relevante, revisar taskboard y mailbox")
        return self._compact_context(lines, max_lines=12, max_chars=1200)

    @staticmethod
    def _should_open_quality_gates(task: WorkTask) -> bool:
        if task.role != Role.ENGINEER:
            return False
        if task.metadata.get("quality_gate_spawned"):
            return False
        if task.metadata.get("skip_quality_gates"):
            return False
        return True

    def _spawn_quality_gates(self, task: WorkTask) -> None:
        review_id = f"{task.task_id}::review"
        qa_id = f"{task.task_id}::qa"
        gate_tasks = [
            WorkTask(
                task_id=review_id,
                title=f"Review {task.title}",
                description="Revisar cambios de implementacion, riesgos y deuda tecnica.",
                role=Role.REVIEWER,
                dependencies=[],
                metadata={"is_gate": True, "parent_task": task.task_id, "gate_type": "review"},
            ),
            WorkTask(
                task_id=qa_id,
                title=f"QA {task.title}",
                description="Validar pruebas, regresion y criterios de salida.",
                role=Role.QA,
                dependencies=[],
                metadata={"is_gate": True, "parent_task": task.task_id, "gate_type": "qa"},
            ),
        ]
        if self._should_open_security_gate(task):
            gate_tasks.append(
                WorkTask(
                    task_id=f"{task.task_id}::security",
                    title=f"Security {task.title}",
                    description=(
                        "Validar seguridad/compliance: secretos, comandos sensibles y "
                        "riesgo operacional."
                    ),
                    role=Role.REVIEWER,
                    dependencies=[],
                    metadata={
                        "is_gate": True,
                        "parent_task": task.task_id,
                        "gate_type": "security",
                        "required_capabilities": ["review"],
                    },
                )
            )

        for gate_task in gate_tasks:
            if not self.taskboard.get_task(gate_task.task_id):
                self.taskboard.add_task(gate_task)

        if self.taskboard.get_task(task.task_id) is not None:
            gate_ids = [gate_task.task_id for gate_task in gate_tasks]
            self.taskboard.update_metadata(
                task.task_id,
                {
                    "quality_gate_spawned": True,
                    "quality_gate_tasks": gate_ids,
                    "provisional_result": "implementation_done_waiting_gates",
                },
            )
            self.event_logger.emit(
                "quality_gates_opened",
                {
                    "task_id": task.task_id,
                    "gates": gate_ids,
                },
            )
            self._notify_gate_agents(task.task_id, gate_ids=gate_ids)

    @staticmethod
    def _should_open_security_gate(task: WorkTask) -> bool:
        if task.metadata.get("skip_security_gate"):
            return False
        if task.metadata.get("require_security_gate"):
            return True
        if task.complexity.value == "high" or task.criticality.value == "high":
            return True
        plan = task.metadata.get("execution_plan", [])
        if not isinstance(plan, list):
            return False
        risky_steps = {"cmd", "powershell", "browser_script"}
        for step in plan:
            if not isinstance(step, dict):
                continue
            step_type = str(step.get("type", "")).strip().lower()
            if step_type in risky_steps:
                return True
        return False

    def _release_blocked_parent_tasks(self) -> None:
        for task in self.taskboard.list_tasks():
            if task.state != TaskState.BLOCKED:
                continue
            gate_tasks = task.metadata.get("quality_gate_tasks", [])
            if not gate_tasks:
                continue
            gate_objects = [self.taskboard.get_task(gate_id) for gate_id in gate_tasks]
            all_completed = True
            for obj in gate_objects:
                if obj is None or obj.state != TaskState.COMPLETED:
                    all_completed = False
                    break
            if all_completed:
                self.taskboard.mark_completed(
                    task.task_id,
                    details="quality_gates_passed",
                )
                self.mailbox.send(
                    sender="system",
                    recipient="team_lead",
                    subject=f"Task released by gates: {task.task_id}",
                    body="Todas las gates de calidad finalizaron correctamente.",
                    task_id=task.task_id,
                )
                self.memory.remember(
                    agent_id="lead-1",
                    role=Role.TEAM_LEAD.value,
                    kind="quality_gate_release",
                    content=f"{task.task_id} released",
                    task_id=task.task_id,
                    tags=["quality", "release"],
                )

    def _run_peer_consultation(self, task: WorkTask, assignee: str) -> str:
        if not self._needs_peer_consultation(task):
            return ""

        peer_roles = self._peer_roles_for(task.role)
        if not peer_roles:
            return ""

        summaries: list[str] = []
        for peer_role in peer_roles:
            peer_agent = self._assignee_for_role(peer_role)
            request = RoutingRequest(
                role=peer_role,
                complexity=task.complexity,
                criticality=task.criticality,
                required_capabilities=self._peer_capabilities(peer_role),
            )
            peer_prompt = self._peer_prompt_for_task(task, peer_role)
            decision = self.router.route_and_invoke(request=request, prompt=peer_prompt)
            if decision.success:
                content = self.compliance.redact_text(decision.response.content)
                self.communicator.send_dm(
                    sender=peer_role.value,
                    recipient=assignee,
                    subject=f"Peer input for {task.task_id}",
                    body=content[:500],
                    task_id=task.task_id,
                )
                self.memory.remember(
                    agent_id=peer_agent,
                    role=peer_role.value,
                    kind="peer_consultation_outbound",
                    content=content,
                    task_id=task.task_id,
                    tags=["peer", "consultation"],
                )
                self.memory.remember(
                    agent_id=assignee,
                    role=task.role.value,
                    kind="peer_consultation_inbound",
                    content=f"{peer_role.value}: {content}",
                    task_id=task.task_id,
                    tags=["peer", "consultation"],
                )
                summaries.append(f"{peer_role.value}: {content[:220]}")
            else:
                summaries.append(
                    f"{peer_role.value}: no disponible ({decision.response.error or decision.reason})"
                )

        return "\n".join(f"- {item}" for item in summaries)

    @staticmethod
    def _needs_peer_consultation(task: WorkTask) -> bool:
        if task.metadata.get("skip_peer_consultation"):
            return False
        if task.metadata.get("require_peer_consultation"):
            return True
        return task.complexity.value == "high" or task.criticality.value == "high"

    @staticmethod
    def _peer_roles_for(role: Role) -> list[Role]:
        mapping = {
            Role.TEAM_LEAD: [Role.RESEARCHER, Role.ENGINEER],
            Role.RESEARCHER: [Role.TEAM_LEAD],
            Role.ENGINEER: [Role.RESEARCHER, Role.REVIEWER],
            Role.REVIEWER: [Role.ENGINEER],
            Role.QA: [Role.ENGINEER],
        }
        return mapping.get(role, [])

    @staticmethod
    def _peer_capabilities(role: Role) -> set[str]:
        mapping = {
            Role.TEAM_LEAD: {"reasoning"},
            Role.RESEARCHER: {"analysis"},
            Role.ENGINEER: {"coding"},
            Role.REVIEWER: {"review"},
            Role.QA: {"analysis"},
        }
        return mapping.get(role, set())

    @staticmethod
    def _peer_prompt_for_task(task: WorkTask, peer_role: Role) -> str:
        if task.complexity.value == "high" or task.criticality.value == "high":
            return (
                f"Actua como {peer_role.value}.\n"
                f"Analiza la tarea {task.task_id}: {task.title}.\n"
                f"Descripcion: {task.description}.\n"
                "Responde en <= 10 lineas con este formato:\n"
                "1) Hipotesis principal\n"
                "2) Contra-hipotesis\n"
                "3) Riesgos clave\n"
                "4) Siguiente paso recomendado"
            )
        return (
            f"Actua como {peer_role.value}.\n"
            f"Analiza la tarea {task.task_id}: {task.title}.\n"
            f"Descripcion: {task.description}.\n"
            "Devuelve recomendaciones concretas, riesgos y orden de ejecucion en <= 8 lineas."
        )

    def _notify_dependents(self, task_id: str, summary: str) -> None:
        for candidate in self.taskboard.list_tasks():
            if task_id not in candidate.dependencies:
                continue
            recipient = self._assignee_for_role(candidate.role)
            self.communicator.send_dm(
                sender="team_lead",
                recipient=recipient,
                subject=f"Dependency ready: {task_id}",
                body=f"La dependencia de {candidate.task_id} esta resuelta. Resumen: {summary[:200]}",
                task_id=candidate.task_id,
            )

    def _notify_gate_agents(self, parent_task_id: str, gate_ids: list[str]) -> None:
        for gate_id in gate_ids:
            gate_task = self.taskboard.get_task(gate_id)
            if gate_task is None:
                continue
            recipient = self._assignee_for_role(gate_task.role)
            gate_type = str(gate_task.metadata.get("gate_type", gate_task.role.value))
            label = gate_type.replace("_", " ").title()
            self.communicator.send_dm(
                sender="team_lead",
                recipient=recipient,
                subject=f"{label} requested: {gate_id}",
                body=f"Validar artefactos de {parent_task_id} ({gate_type}).",
                task_id=gate_id,
            )

    def _build_collaboration_context(self, task: WorkTask, assignee: str) -> str:
        excluded_memory = {"meeting_minutes"}
        relevant_memory = self.memory.relevant(
            assignee,
            task.description,
            limit=3,
            exclude_kinds=excluded_memory,
        )
        recent_memory = self.memory.recent(
            assignee,
            limit=2,
            exclude_kinds=excluded_memory,
        )
        dm_messages = self._context_messages(recipient=assignee)
        role_messages = self._context_messages(recipient=task.role.value)

        lines: list[str] = []
        if relevant_memory:
            lines.append("Memoria relevante:")
            for entry in relevant_memory:
                lines.append(f"- [{entry.kind}] {self._compact_text(entry.content, 180)}")
        if recent_memory:
            lines.append("Memoria reciente:")
            for entry in recent_memory:
                lines.append(f"- [{entry.kind}] {self._compact_text(entry.content, 140)}")
        if dm_messages or role_messages:
            lines.append("Mensajes recientes:")
            for message in (dm_messages + role_messages)[-6:]:
                lines.append(
                    "- "
                    f"{message.sender} -> {message.recipient}: {message.subject} | "
                    f"{self._compact_text(message.body, 120)}"
                )
        return self._compact_context(lines, max_lines=16, max_chars=1800)

    def _build_skill_mcp_context(self, task: WorkTask, assignee: str) -> str:
        required = {
            item.strip().lower()
            for item in task.metadata.get("required_capabilities", [])
            if str(item).strip()
        }
        guidance = self.tool_integrator.guidance_for_task(
            role=task.role.value,
            description=f"{task.title}\n{task.description}",
            required_capabilities=required,
        )
        text = str(guidance.get("text", "")).strip()
        if not text:
            return ""
        compacted = self._compact_context(text.splitlines(), max_lines=14, max_chars=1200)
        self.memory.remember(
            agent_id=assignee,
            role=task.role.value,
            kind="skill_mcp_guidance",
            content=compacted,
            task_id=task.task_id,
            tags=["skills", "mcp", "guidance"],
        )
        self.event_logger.emit(
            "skill_mcp_guidance",
            {
                "task_id": task.task_id,
                "role": task.role.value,
                "skills": guidance.get("skills", []),
                "recommended_mcp": guidance.get("recommended_mcp", []),
                "active_mcp": guidance.get("active_mcp", []),
            },
        )
        return compacted

    def _integrate_tools_for_task(
        self,
        *,
        task: WorkTask,
        assignee: str,
        internet_allowed: bool,
    ) -> ToolIntegrationReport:
        report = self.tool_integrator.integrate_from_metadata(
            task_id=task.task_id,
            metadata=task.metadata,
            internet_allowed=internet_allowed,
        )
        if report.messages:
            summary = "; ".join(report.messages)[:500]
            self.memory.remember(
                agent_id=assignee,
                role=task.role.value,
                kind="tool_integration",
                content=summary,
                task_id=task.task_id,
                tags=["tools", "integration"],
            )
        if report.integrated_adapters or report.integrated_mcp_servers or report.integrated_skills:
            self.event_logger.emit(
                "tool_integration",
                {
                    "task_id": task.task_id,
                    "success": report.success,
                    "adapters": report.integrated_adapters,
                    "mcp_servers": report.integrated_mcp_servers,
                    "skills": report.integrated_skills,
                    "errors": report.errors,
                },
            )
        return report

    def _auto_discover_tools(
        self,
        *,
        task: WorkTask,
        assignee: str,
        internet_allowed: bool,
    ) -> ToolIntegrationReport:
        required = {
            item.strip().lower()
            for item in task.metadata.get("required_capabilities", [])
            if str(item).strip()
        }
        suggestions = self.tool_integrator.suggest_requirements(required, limit=3)
        if not suggestions:
            return ToolIntegrationReport(success=True)

        prepared = []
        for item in suggestions:
            row = dict(item)
            row.setdefault("required", False)
            row["enabled"] = True
            prepared.append(row)

        metadata = {"tool_requirements": prepared}
        report = self.tool_integrator.integrate_from_metadata(
            task_id=f"{task.task_id}::auto_discovery",
            metadata=metadata,
            internet_allowed=internet_allowed,
        )
        if report.messages:
            self.memory.remember(
                agent_id=assignee,
                role=task.role.value,
                kind="tool_auto_discovery",
                content="; ".join(report.messages)[:500],
                task_id=task.task_id,
                tags=["tools", "auto_discovery"],
            )
        if report.integrated_adapters or report.integrated_skills or report.integrated_mcp_servers:
            self.event_logger.emit(
                "tool_auto_discovery",
                {
                    "task_id": task.task_id,
                    "required_capabilities": sorted(required),
                    "success": report.success,
                    "integrated_adapters": report.integrated_adapters,
                    "integrated_skills": report.integrated_skills,
                    "integrated_mcp_servers": report.integrated_mcp_servers,
                    "errors": report.errors,
                },
            )
        return report

    def _sync_router_external_adapters(self) -> None:
        external = load_external_adapters(self.runtime_dir / "adapters.json")
        if not external:
            return
        external_names = [adapter.name for adapter in external]
        existing = {adapter.name: adapter for adapter in self.router.adapters}
        merged = [existing.get(adapter.name, adapter) for adapter in external]
        for adapter in self.router.adapters:
            if adapter.name in external_names:
                continue
            merged.append(adapter)
        self.router.adapters = merged

    def _context_messages(self, recipient: str) -> list:
        messages = self.mailbox.list_messages(recipient=recipient)
        filtered = [
            message
            for message in messages
            if not message.subject.lower().startswith("sync meeting:")
        ]
        return filtered[-4:]

    def _compact_text(self, value: str, max_chars: int) -> str:
        clean = self.compliance.redact_text(value.strip().replace("\n", " "))
        if len(clean) <= max_chars:
            return clean
        if max_chars <= 3:
            return clean[:max_chars]
        return clean[: max_chars - 3] + "..."

    def _compact_context(self, lines: list[str], max_lines: int, max_chars: int) -> str:
        compacted = [self._compact_text(line, 220) for line in lines if line.strip()]
        if len(compacted) > max_lines:
            compacted = compacted[:max_lines]
        output = "\n".join(compacted)
        if len(output) <= max_chars:
            return output
        return self._compact_text(output, max_chars)

    def _compose_execution_context(self, results: list) -> str:
        lines = []
        for index, result in enumerate(results, start=1):
            stdout = self._compact_text(result.stdout or "", 180)
            stderr = self._compact_text(result.stderr or "", 180)
            safe_command = self._compact_text(result.command or "", 140)
            lines.append(
                f"{index}. [{result.step_type}] success={result.success} exit={result.exit_code} "
                f"cmd={safe_command} stdout={stdout} stderr={stderr} reason={result.reason}"
            )
        return "\n".join(lines)

    def _fail_task_due_to_compliance(
        self,
        task: WorkTask,
        assignee: str,
        reason: str,
        details: list[str],
    ) -> None:
        safe_details = [self._compact_text(item, 140) for item in details]
        body = f"reason={reason} details={safe_details}"
        self.taskboard.mark_failed(task.task_id, error=reason)
        self.memory.remember(
            agent_id=assignee,
            role=task.role.value,
            kind="compliance_violation",
            content=body,
            task_id=task.task_id,
            tags=["compliance", "blocked"],
        )
        self.event_logger.emit(
            "compliance_violation",
            {
                "task_id": task.task_id,
                "assignee": assignee,
                "environment": self.environment,
                "reason": reason,
                "details": safe_details,
            },
        )
        self.mailbox.send(
            sender="compliance",
            recipient="team_lead",
            subject=f"Task blocked by compliance: {task.task_id}",
            body=body,
            task_id=task.task_id,
        )
        self._maybe_run_event_meeting(
            trigger="compliance_violation",
            task_id=task.task_id,
            reason=reason,
        )

    @staticmethod
    def _to_bool(value: object) -> bool:
        if isinstance(value, bool):
            return value
        normalized = str(value).strip().lower()
        return normalized in {"1", "true", "yes", "on"}

    def _run_round_sync_meeting(self) -> None:
        participants = [
            MeetingParticipant(agent_id="lead-1", role=Role.TEAM_LEAD.value),
            MeetingParticipant(agent_id="research-1", role=Role.RESEARCHER.value),
            MeetingParticipant(agent_id="eng-1", role=Role.ENGINEER.value),
            MeetingParticipant(agent_id="review-1", role=Role.REVIEWER.value),
            MeetingParticipant(agent_id="qa-1", role=Role.QA.value),
        ]
        self.communicator.run_sync_meeting(
            topic=f"Round {self._round}",
            participants=participants,
        )

    def _maybe_run_event_meeting(self, trigger: str, task_id: str, reason: str) -> None:
        key = f"{trigger}:{task_id}"
        if self._last_event_meeting_round.get(key) == self._round:
            return
        self._last_event_meeting_round[key] = self._round
        participants = [
            MeetingParticipant(agent_id="lead-1", role=Role.TEAM_LEAD.value),
            MeetingParticipant(agent_id="research-1", role=Role.RESEARCHER.value),
            MeetingParticipant(agent_id="eng-1", role=Role.ENGINEER.value),
            MeetingParticipant(agent_id="review-1", role=Role.REVIEWER.value),
            MeetingParticipant(agent_id="qa-1", role=Role.QA.value),
        ]
        self.communicator.run_sync_meeting(
            topic=f"Event {trigger} @ {task_id} reason={reason}",
            participants=participants,
            task_id=task_id,
        )

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class MailMessage:
    timestamp: str
    sender: str
    recipient: str
    subject: str
    body: str
    task_id: str | None = None


class Mailbox:
    def __init__(self, storage_path: Path) -> None:
        self.storage_path = storage_path
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.storage_path.exists():
            self.storage_path.write_text("", encoding="utf-8")

    def send(
        self,
        sender: str,
        recipient: str,
        subject: str,
        body: str,
        task_id: str | None = None,
    ) -> None:
        msg = MailMessage(
            timestamp=datetime.now(timezone.utc).isoformat(),
            sender=sender,
            recipient=recipient,
            subject=subject,
            body=body,
            task_id=task_id,
        )
        with self.storage_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(msg), ensure_ascii=True) + "\n")

    def list_messages(self, recipient: str | None = None) -> list[MailMessage]:
        raw = self.storage_path.read_text(encoding="utf-8")
        items: list[MailMessage] = []
        for line in raw.splitlines():
            if not line.strip():
                continue
            data = json.loads(line)
            if recipient and data.get("recipient") not in (recipient, "broadcast"):
                continue
            items.append(MailMessage(**data))
        return items

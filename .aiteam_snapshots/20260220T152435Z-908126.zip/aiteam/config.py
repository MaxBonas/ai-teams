from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class RouterPolicy:
    pro_first: bool = True
    max_subscription_attempts: int = 3
    max_api_attempts: int = 2
    api_fallback_enabled: bool = True
    complexity_threshold_for_api: str = "high"
    criticality_threshold_for_api: str = "high"
    preferred_subscription_providers: list[str] = field(
        default_factory=lambda: ["openai", "google", "anthropic"]
    )
    preferred_api_providers: list[str] = field(default_factory=lambda: ["openai"])
    daily_api_budget_usd: float = 10.0
    monthly_api_budget_usd: float = 200.0


def build_default_router_policy() -> RouterPolicy:
    return RouterPolicy()
